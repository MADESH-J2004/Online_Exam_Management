from fastapi import FastAPI
import mysql.connector
from mysql.connector import pooling
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import pickle
from datetime import datetime
import httpx
import json
import re
import hashlib
from typing import Optional

app = FastAPI()
model = pickle.load(open("model.pkl", "rb"))

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── CONNECTION POOL ──
db_pool = pooling.MySQLConnectionPool(
    pool_name="exam_pool",
    pool_size=10,
    host="localhost",
    user="root",
    password="",
    database="online_exam"
)

def db():
    return db_pool.get_connection()

def hash_pwd(pwd: str) -> str:
    return hashlib.sha256(pwd.encode()).hexdigest()

# ── USERS ──
@app.get("/get_users")
def get_users():
    c = db(); cur = c.cursor(dictionary=True)
    cur.execute("SELECT user_id,name,email,role,status FROM users_table")
    d = cur.fetchall(); cur.close(); c.close(); return d

# ── EXAMS ──
@app.get("/get_exam")
def get_exam():
    c = db(); cur = c.cursor(dictionary=True)
    cur.execute("SELECT exam_id as id, exam_name, subject_name, duration, total_marks, start_date FROM exam_table ORDER BY exam_id DESC")
    d = cur.fetchall(); cur.close(); c.close(); return d

@app.get("/get_exam/{exam_id}")
def get_exam_by_id(exam_id: int):
    c = db(); cur = c.cursor(dictionary=True)
    cur.execute("SELECT exam_id as id, exam_name, subject_name, duration, total_marks, start_date FROM exam_table WHERE exam_id=%s", (exam_id,))
    d = cur.fetchone(); cur.close(); c.close(); return d or {}

class ExamCreate(BaseModel):
    exam_name: str
    subject_name: str
    duration: int
    total_marks: int
    start_date: str
    end_date: str
    num_questions: int = 5
    difficulty: str = "Mixed"

@app.post("/create_exam")
async def create_exam(exam: ExamCreate):
    c = db(); cur = c.cursor(dictionary=True)
    cur.execute(
        "INSERT INTO exam_table (exam_name, subject_name, duration, total_marks, start_date, end_date) VALUES (%s,%s,%s,%s,%s,%s)",
        (exam.exam_name, exam.subject_name, exam.duration, exam.total_marks, exam.start_date, exam.end_date)
    )
    c.commit()
    exam_id = cur.lastrowid
    questions = await generate_questions(exam.subject_name, exam.num_questions, exam.difficulty, exam_id, cur, c)
    cur.close(); c.close()
    return {"message": "Exam created", "exam_id": exam_id, "questions_generated": len(questions)}

class ExamUpdate(BaseModel):
    exam_name: Optional[str] = None
    subject_name: Optional[str] = None
    duration: Optional[int] = None
    total_marks: Optional[int] = None
    start_date: Optional[str] = None

@app.put("/update_exam/{exam_id}")
def update_exam(exam_id: int, exam: ExamUpdate):
    c = db(); cur = c.cursor()
    fields, vals = [], []
    if exam.exam_name:    fields.append("exam_name=%s");    vals.append(exam.exam_name)
    if exam.subject_name: fields.append("subject_name=%s"); vals.append(exam.subject_name)
    if exam.duration:     fields.append("duration=%s");     vals.append(exam.duration)
    if exam.total_marks:  fields.append("total_marks=%s");  vals.append(exam.total_marks)
    if exam.start_date:   fields.append("start_date=%s");   vals.append(exam.start_date)
    if fields:
        vals.append(exam_id)
        cur.execute(f"UPDATE exam_table SET {','.join(fields)} WHERE exam_id=%s", vals)
        c.commit()
    cur.close(); c.close()
    return {"message": "Updated"}

async def generate_questions(subject, num, difficulty, exam_id, cur, c):
    prompt = f"""Generate exactly {num} multiple choice questions about {subject}.
Difficulty: {difficulty}
Return ONLY a valid JSON array, no markdown, no extra text:
[
  {{
    "question": "Question text?",
    "option_a": "Option A",
    "option_b": "Option B",
    "option_c": "Option C",
    "option_d": "Option D",
    "correct_answer": "option_a",
    "difficulty": "Easy"
  }}
]
correct_answer must be exactly one of: option_a, option_b, option_c, option_d"""

    try:
        async with httpx.AsyncClient(timeout=120.0) as client:
            r = await client.post("http://localhost:11434/api/generate",
                json={"model": "llama3", "prompt": prompt, "stream": False, "options": {"temperature": 0.7}})
            raw = r.json().get("response", "")
            match = re.search(r'\[.*\]', raw, re.DOTALL)
            if match:
                qs = json.loads(match.group())
                saved = []
                for q in qs:
                    cmap = {"option_a": q.get("option_a",""), "option_b": q.get("option_b",""),
                            "option_c": q.get("option_c",""), "option_d": q.get("option_d","")}
                    correct_val = cmap.get(q.get("correct_answer","option_a"), q.get("option_a",""))
                    diff = q.get("difficulty", difficulty if difficulty != "Mixed" else "Medium")
                    cur.execute(
                        "INSERT INTO question_table (exam_id, question_title, option_a, option_b, option_c, option_d, correct_answer, mode) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)",
                        (exam_id, q["question"], q["option_a"], q["option_b"], q["option_c"], q["option_d"], correct_val, diff)
                    )
                    c.commit()
                    saved.append(q)
                return saved
    except Exception as e:
        print(f"Ollama error: {e}")

    # Fallback questions if Ollama fails
    subjects_map = {
        "mathematics": [("What is 15% of 200?", "30", "25", "40", "35", "30"),
                        ("Solve: 2x + 5 = 15", "x=5", "x=4", "x=6", "x=3", "x=5"),
                        ("What is the area of a circle with radius 7?", "153.94", "44", "78", "100", "153.94"),
                        ("What is sqrt(144)?", "12", "14", "11", "13", "12"),
                        ("What is 3^4?", "81", "64", "27", "36", "81")],
        "physics":     [("Unit of force?", "Newton", "Joule", "Watt", "Pascal", "Newton"),
                        ("Speed of light?", "3x10^8 m/s", "3x10^6 m/s", "3x10^10 m/s", "3x10^4 m/s", "3x10^8 m/s")],
        "chemistry":   [("Formula for water?", "H2O", "CO2", "O2", "H2O2", "H2O"),
                        ("Atomic number of Carbon?", "6", "12", "8", "4", "6")],
    }
    subject_key = subject.strip().lower()
    fallback_qs = subjects_map.get(subject_key, [
        (f"{subject} question {i+1}?", "Option A", "Option B", "Option C", "Option D", "Option A") for i in range(num)
    ])
    saved = []
    for i in range(min(num, len(fallback_qs))):
        q = fallback_qs[i]
        cur.execute(
            "INSERT INTO question_table (exam_id, question_title, option_a, option_b, option_c, option_d, correct_answer, mode) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)",
            (exam_id, q[0], q[1], q[2], q[3], q[4], q[5], "Medium")
        )
        c.commit()
        saved.append(q)
    return saved

# ── QUESTIONS ──
@app.get("/get_quiz")
def get_quiz():
    c = db(); cur = c.cursor(dictionary=True)
    cur.execute("SELECT question_id as id, exam_id, question_title, option_a, option_b, option_c, option_d, correct_answer, mode FROM question_table")
    d = cur.fetchall(); cur.close(); c.close(); return d

@app.get("/get_quiz/{exam_id}")
def get_quiz_by_exam(exam_id: int):
    c = db(); cur = c.cursor(dictionary=True)
    cur.execute(
        "SELECT question_id as id, exam_id, question_title, option_a, option_b, option_c, option_d, correct_answer, mode FROM question_table WHERE exam_id=%s",
        (exam_id,)
    )
    d = cur.fetchall(); cur.close(); c.close(); return d

# ── ANSWERS ──
class Answer(BaseModel):
    user_id: int; exam_id: int; question_id: int; selected_answer: str

@app.post("/post_answer")
def post_answer(ans: Answer):
    c = db(); cur = c.cursor(dictionary=True)
    cur.execute("SELECT correct_answer FROM question_table WHERE question_id=%s", (ans.question_id,))
    q = cur.fetchone()
    mark = 1 if q and ans.selected_answer == q["correct_answer"] else 0
    cur.execute("INSERT INTO answer_table (user_id,exam_id,question_id,selected_answer,mark) VALUES (%s,%s,%s,%s,%s)",
        (ans.user_id, ans.exam_id, ans.question_id, ans.selected_answer, mark))
    c.commit(); cur.close(); c.close()
    return {"mark": mark}

# ── RESULT ──
class ResultReq(BaseModel):
    user_id: int; exam_id: int

@app.post("/get_result")
def get_result(data: ResultReq):
    c = db(); cur = c.cursor(dictionary=True)
    cur.execute("SELECT COUNT(*) as total FROM answer_table WHERE user_id=%s AND exam_id=%s", (data.user_id, data.exam_id))
    total = cur.fetchone()["total"]
    cur.execute("SELECT COUNT(*) as correct FROM answer_table WHERE user_id=%s AND exam_id=%s AND mark=1", (data.user_id, data.exam_id))
    correct = cur.fetchone()["correct"]
    wrong = total - correct
    pct = (correct / total * 100) if total > 0 else 0
    status = "PASS" if pct >= 40 else "FAIL"
    ml = model.predict([[4, 75, pct]])[0]
    risk = "HIGH" if pct < 40 else ("MEDIUM" if pct < 70 else "LOW")
    try:
        cur.execute("ALTER TABLE result_table ADD COLUMN IF NOT EXISTS ml_prediction varchar(10)")
        cur.execute("ALTER TABLE result_table ADD COLUMN IF NOT EXISTS risk_level varchar(10)")
        c.commit()
    except: pass
    cur.execute(
        "INSERT INTO result_table (user_id,exam_id,total_quiz,correct_answers,wrong_answers,percentage,result_status) VALUES (%s,%s,%s,%s,%s,%s,%s)",
        (data.user_id, data.exam_id, total, correct, wrong, int(pct), status)
    )
    c.commit(); cur.close(); c.close()
    return {"total": total, "correct": correct, "wrong": wrong, "percentage": pct, "status": status, "ml_prediction": ml, "risk_level": risk}

# ── ACTIVITY ──
class ActivityLog(BaseModel):
    user_name: str; exam_name: str; activity: str; severity: str

@app.post("/log_activity")
def log_activity(act: ActivityLog):
    c = db(); cur = c.cursor()
    cur.execute("INSERT INTO activity_table (user_name,exam_name,activity,severity,time) VALUES (%s,%s,%s,%s,%s)",
        (act.user_name, act.exam_name, act.activity, act.severity, datetime.now()))
    c.commit(); cur.close(); c.close()
    return {"ok": True}

@app.get("/get_activity")
def get_activity():
    c = db(); cur = c.cursor(dictionary=True)
    cur.execute("SELECT id,user_name,exam_name,activity,severity,time FROM activity_table ORDER BY id DESC LIMIT 20")
    d = cur.fetchall(); cur.close(); c.close(); return d

@app.get("/get_activity_stats")
def get_activity_stats():
    c = db(); cur = c.cursor(dictionary=True)
    cur.execute("SELECT COUNT(*) as total FROM activity_table"); total = cur.fetchone()["total"]
    cur.execute("SELECT COUNT(DISTINCT user_name) as s FROM activity_table"); students = cur.fetchone()["s"]
    cur.execute("SELECT COUNT(*) as w FROM activity_table WHERE severity IN ('HIGH','MEDIUM')"); warnings = cur.fetchone()["w"]
    cur.close(); c.close()
    return {"total_alerts": total, "students_monitored": students, "warnings_issued": warnings}

# ── STATS ──
@app.get("/stats")
def get_stats():
    c = db(); cur = c.cursor(dictionary=True)
    cur.execute("SELECT COUNT(*) as u FROM users_table"); u = cur.fetchone()["u"]
    cur.execute("SELECT COUNT(*) as e FROM exam_table"); e = cur.fetchone()["e"]
    cur.execute("SELECT COUNT(*) as q FROM question_table"); q = cur.fetchone()["q"]
    cur.close(); c.close()
    return {"total_students": u, "total_exams": e, "total_questions": q}

# ── OLLAMA STATUS ──
@app.get("/ollama_status")
async def ollama_status():
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            r = await client.get("http://localhost:11434/api/tags")
            models = r.json().get("models", [])
            return {"status": "online", "models": [m["name"] for m in models]}
    except:
        return {"status": "offline", "models": []}

# ── QUESTION CRUD ──
class QuestionCreate(BaseModel):
    exam_id: int
    question_title: str
    option_a: str
    option_b: str
    option_c: str
    option_d: str
    correct_answer: str
    mode: str = "Easy"

@app.post("/add_question")
def add_question(q: QuestionCreate):
    c = db(); cur = c.cursor()
    cur.execute("""
        INSERT INTO question_table
        (exam_id, question_title, option_a, option_b, option_c, option_d, correct_answer, mode)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
    """, (q.exam_id, q.question_title, q.option_a, q.option_b,
          q.option_c, q.option_d, q.correct_answer, q.mode))
    c.commit()
    new_id = cur.lastrowid
    cur.close(); c.close()
    return {"message": "Question added", "id": new_id}

@app.put("/update_question/{question_id}")
def update_question(question_id: int, q: QuestionCreate):
    c = db(); cur = c.cursor()
    cur.execute("""
        UPDATE question_table SET
        exam_id=%s, question_title=%s, option_a=%s, option_b=%s,
        option_c=%s, option_d=%s, correct_answer=%s, mode=%s
        WHERE question_id=%s
    """, (q.exam_id, q.question_title, q.option_a, q.option_b,
          q.option_c, q.option_d, q.correct_answer, q.mode, question_id))
    c.commit(); cur.close(); c.close()
    return {"message": "Question updated"}

@app.delete("/delete_question/{question_id}")
def delete_question(question_id: int):
    c = db(); cur = c.cursor()
    cur.execute("DELETE FROM question_table WHERE question_id=%s", (question_id,))
    c.commit(); cur.close(); c.close()
    return {"message": "Question deleted"}

# ── RESULTS PAGE ──
@app.get("/results")
def get_all_results():
    c = db(); cur = c.cursor(dictionary=True)
    cur.execute("""
        SELECT r.result_id, r.user_id, r.exam_id, r.total_quiz,
               r.correct_answers, r.wrong_answers, r.percentage,
               r.result_status, r.result_date,
               u.name as user_name,
               e.exam_name, e.subject_name, e.total_marks
        FROM result_table r
        LEFT JOIN users_table u ON r.user_id = u.user_id
        LEFT JOIN exam_table e ON r.exam_id = e.exam_id
        ORDER BY r.percentage DESC
    """)
    data = cur.fetchall(); cur.close(); c.close(); return data

@app.get("/results/summary")
def get_results_summary():
    c = db(); cur = c.cursor(dictionary=True)
    cur.execute("SELECT COUNT(*) as total FROM result_table")
    total = cur.fetchone()["total"]
    cur.execute("SELECT AVG(percentage) as avg_pct FROM result_table")
    avg_pct = float((cur.fetchone()["avg_pct"] or 0))
    cur.execute("SELECT COUNT(*) as passed FROM result_table WHERE result_status='PASS'")
    passed = cur.fetchone()["passed"]
    cur.execute("SELECT MAX(percentage) as top FROM result_table")
    top = cur.fetchone()["top"] or 0
    cur.execute("""
        SELECT e.subject_name, e.exam_name,
               AVG(r.percentage) as avg_pct,
               COUNT(r.result_id) as attempts
        FROM result_table r
        LEFT JOIN exam_table e ON r.exam_id = e.exam_id
        GROUP BY r.exam_id, e.subject_name, e.exam_name
        ORDER BY avg_pct DESC
    """)
    subjects = cur.fetchall(); cur.close(); c.close()
    return {
        "total_results": total,
        "avg_percentage": round(avg_pct, 1),
        "passed": passed,
        "failed": total - passed,
        "top_score": float(top),
        "pass_rate": round((passed / total * 100), 1) if total > 0 else 0,
        "subjects": subjects
    }

@app.get("/results/user/{user_id}")
def get_results_by_user(user_id: int):
    c = db(); cur = c.cursor(dictionary=True)
    cur.execute("""
        SELECT r.result_id, r.user_id, r.exam_id, r.total_quiz,
               r.correct_answers, r.wrong_answers, r.percentage,
               r.result_status, r.result_date,
               u.name as user_name,
               e.exam_name, e.subject_name, e.total_marks
        FROM result_table r
        LEFT JOIN users_table u ON r.user_id = u.user_id
        LEFT JOIN exam_table e ON r.exam_id = e.exam_id
        WHERE r.user_id = %s
        ORDER BY r.result_date DESC
    """, (user_id,))
    data = cur.fetchall(); cur.close(); c.close(); return data

# ─────────────────────────────────────────────────────────────────────────────
# AUTH  (Login / Register / Forgot-Password)
# ─────────────────────────────────────────────────────────────────────────────

class LoginReq(BaseModel):
    email: str
    password: str

class RegisterReq(BaseModel):
    name: str
    email: str
    password: str
    role: str = "student"

class CheckEmailReq(BaseModel):
    email: str

class DirectResetReq(BaseModel):
    email: str
    new_password: str


# ==============================
# 🔑 LOGIN
# ==============================
@app.post("/login")
def login(data: LoginReq):
    c = db()
    cur = c.cursor(dictionary=True)

    cur.execute(
        "SELECT user_id, name, email, role, status, password FROM users_table WHERE email=%s",
        (data.email,)
    )
    user = cur.fetchone()

    cur.close()
    c.close()

    if not user:
        return {"error": "Invalid email or password."}

    # ✅ plain text check
    if user["password"] != data.password:
        return {"error": "Invalid email or password."}

    if (user.get("status") or "").lower() != "active":
        return {"error": "Account is not active. Contact admin."}

    return {
        "user_id": user["user_id"],
        "name": user["name"],
        "email": user["email"],
        "role": user["role"],
        "status": user["status"],
    }


# ==============================
# 📝 REGISTER
# ==============================
@app.post("/register")
def register(data: RegisterReq):
    c = db()
    cur = c.cursor(dictionary=True)

    # check existing email
    cur.execute("SELECT user_id FROM users_table WHERE email=%s", (data.email,))
    if cur.fetchone():
        cur.close()
        c.close()
        return {"error": "Email already registered."}

    # insert user (plain text password)
    cur.execute(
        "INSERT INTO users_table (name, email, password, role, status) VALUES (%s,%s,%s,%s,'active')",
        (data.name, data.email, data.password, data.role)
    )

    c.commit()
    new_id = cur.lastrowid

    cur.close()
    c.close()

    return {"message": "Account created", "user_id": new_id}


# ==============================
# 📧 STEP 1: CHECK EMAIL
# ==============================
@app.post("/check-email")
def check_email(data: CheckEmailReq):
    c = db()
    cur = c.cursor(dictionary=True)

    cur.execute("SELECT user_id FROM users_table WHERE email=%s", (data.email,))
    user = cur.fetchone()

    cur.close()
    c.close()

    if not user:
        return {"error": "Email not found. Please check and try again."}

    return {"message": "Email verified."}


# ==============================
# 🔁 STEP 2: RESET PASSWORD
# ==============================
@app.post("/reset-password-direct")
def reset_password_direct(data: DirectResetReq):

    if not data.new_password or len(data.new_password) < 6:
        return {"error": "Password must be at least 6 characters."}

    c = db()
    cur = c.cursor()

    # update password (plain text)
    cur.execute(
        "UPDATE users_table SET password=%s WHERE email=%s",
        (data.new_password, data.email)
    )

    if cur.rowcount == 0:
        cur.close()
        c.close()
        return {"error": "Email not found."}

    c.commit()

    cur.close()
    c.close()

    return {"message": "Password reset successfully."}