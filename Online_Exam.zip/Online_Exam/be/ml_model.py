import pandas as pd
import pickle
from sklearn.linear_model import LogisticRegression

# Sample dataset
data = {
    "study_hours": [1, 2, 3, 4, 5, 6, 7, 8],
    "attendance": [50, 60, 65, 70, 75, 80, 85, 90],
    "previous_marks": [30, 35, 40, 50, 60, 70, 80, 90],
    "result": ["FAIL", "FAIL", "FAIL", "PASS", "PASS", "PASS", "PASS", "PASS"]
}

df = pd.DataFrame(data)

X = df[["study_hours", "attendance", "previous_marks"]]
y = df["result"]

# Train model
model = LogisticRegression()
model.fit(X, y)

# Save model
pickle.dump(model, open("model.pkl", "wb"))

print("✅ Model trained and saved as model.pkl")