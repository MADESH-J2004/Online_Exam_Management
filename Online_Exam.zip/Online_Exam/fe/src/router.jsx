import React from "react";
import { createBrowserRouter, Navigate } from "react-router-dom";
import Login from "./pages/Login";
import Register from "./pages/Register";
import ForgotPassword from "./pages/ForgotPassword";
import Dashboard from "./pages/Dashboard";
import ExamManagement from "./pages/ExamManagement";
import ExamView from "./pages/ExamView";
import Examination from "./pages/Examination";
import QuestionBank from "./pages/QuestionBank";
import Report from "./pages/Report";
import Evaluation from "./pages/Evaluation";
import StudentDashboard from "./pages/StudentDashboard";
import TeacherDashboard from "./pages/TeacherDashboard";
import StudentExams from "./pages/StudentExams";
import StudentResults from "./pages/StudentResults";

function ProtectedRoute({ children, roles }) {
  const userRaw = localStorage.getItem("exam_user");
  if (!userRaw) return <Navigate to="/login" replace />;
  if (roles) {
    const user = JSON.parse(userRaw);
    const role = (user.role || "").toLowerCase();
    if (!roles.includes(role)) {
      // Redirect to correct dashboard
      if (role === "student") return <Navigate to="/student" replace />;
      if (role === "teacher") return <Navigate to="/teacher" replace />;
      return <Navigate to="/" replace />;
    }
  }
  return children;
}

const router = createBrowserRouter([
  { path: "/login", element: <Login /> },
  { path: "/register", element: <Register /> },
  { path: "/forgot-password", element: <ForgotPassword /> },

  // Admin routes
  { path: "/", element: <ProtectedRoute roles={["admin"]}><Dashboard /></ProtectedRoute> },
  { path: "/exams", element: <ProtectedRoute roles={["admin", "teacher"]}><ExamManagement /></ProtectedRoute> },
  { path: "/exams/:examId", element: <ProtectedRoute roles={["admin", "teacher"]}><ExamView /></ProtectedRoute> },
  { path: "/questions", element: <ProtectedRoute roles={["admin", "teacher"]}><QuestionBank /></ProtectedRoute> },
  { path: "/results", element: <ProtectedRoute roles={["admin", "teacher"]}><Report /></ProtectedRoute> },
  { path: "/evaluation", element: <ProtectedRoute roles={["admin", "teacher"]}><Evaluation /></ProtectedRoute> },
  { path: "/security", element: <ProtectedRoute roles={["admin"]}><Dashboard /></ProtectedRoute> },
  { path: "/users", element: <ProtectedRoute roles={["admin"]}><Dashboard /></ProtectedRoute> },

  // Student routes
  { path: "/student", element: <ProtectedRoute roles={["student"]}><StudentDashboard /></ProtectedRoute> },
  { path: "/student/exams", element: <ProtectedRoute roles={["student"]}><StudentExams /></ProtectedRoute> },
  { path: "/student/results", element: <ProtectedRoute roles={["student"]}><StudentResults /></ProtectedRoute> },
  { path: "/exam/:examId", element: <ProtectedRoute roles={["student"]}><Examination /></ProtectedRoute> },

  // Teacher routes
  { path: "/teacher", element: <ProtectedRoute roles={["teacher"]}><TeacherDashboard /></ProtectedRoute> },

  { path: "*", element: <RoleRedirect /> },
]);

function RoleRedirect() {
  const userRaw = localStorage.getItem("exam_user");
  if (!userRaw) return <Navigate to="/login" replace />;
  const user = JSON.parse(userRaw);
  const role = (user.role || "").toLowerCase();
  if (role === "student") return <Navigate to="/student" replace />;
  if (role === "teacher") return <Navigate to="/teacher" replace />;
  return <Navigate to="/" replace />;
}

export default router;
