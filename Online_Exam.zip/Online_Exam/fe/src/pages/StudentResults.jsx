import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import "../styles/Dashboard.css";

function StudentResults() {
  const navigate = useNavigate();
  const userRaw = localStorage.getItem("exam_user");
  const user = userRaw ? JSON.parse(userRaw) : null;
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { navigate("/login"); return; }
    fetch(`http://127.0.0.1:8000/results/user/${user.user_id}`)
      .then(r => r.json())
      .then(data => {
        setResults(Array.isArray(data) ? data : []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const avg = results.length
    ? Math.round(results.reduce((s, r) => s + (r.percentage || 0), 0) / results.length)
    : 0;

  return (
    <div className="dashboard-container">
      <div className="student-sidebar">
        <h2 className="logo">📚 Smart Exam</h2>
        <ul>
          <li onClick={() => navigate("/student")}>🏠 Dashboard</li>
          <li onClick={() => navigate("/student/exams")}>📋 Available Exams</li>
          <li className="active">📊 My Results</li>
        </ul>
      </div>
      <div className="dashboard-main">
        <Navbar />
        <div className="dashboard-content">
          <h2>My Results</h2>
          <p className="subtitle">Your exam history and performance.</p>

          <div className="stats" style={{ marginBottom: 24 }}>
            <div className="stat-card"><h4>Total Exams</h4><h1>{results.length}</h1></div>
            <div className="stat-card"><h4>Avg Score</h4><h1>{avg}%</h1></div>
            <div className="stat-card"><h4>Passed</h4><h1>{results.filter(r => r.result_status === "PASS").length}</h1></div>
            <div className="stat-card"><h4>Failed</h4><h1>{results.filter(r => r.result_status === "FAIL").length}</h1></div>
          </div>

          {loading ? <p>Loading...</p> : (
            <div className="section-card">
              <table className="exam-table">
                <thead>
                  <tr>
                    <th>Exam</th>
                    <th>Subject</th>
                    <th>Score</th>
                    <th>Status</th>
                    <th>Date</th>
                  </tr>
                </thead>
                <tbody>
                  {results.length === 0 && (
                    <tr><td colSpan={5} style={{ textAlign: "center", color: "#888" }}>No results yet.</td></tr>
                  )}
                  {results.map(r => (
                    <tr key={r.result_id}>
                      <td>{r.exam_name || "Exam"}</td>
                      <td>{r.subject_name || "—"}</td>
                      <td>{r.correct_answers}/{r.total_quiz} ({r.percentage}%)</td>
                      <td>
                        <span className={`status ${r.result_status === "PASS" ? "active" : "inactive"}`}>
                          {r.result_status}
                        </span>
                      </td>
                      <td>{r.result_date ? new Date(r.result_date).toLocaleDateString() : "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default StudentResults;
