import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import "./Auth.css";

function Register() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "", confirm: "", role: "student" });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [showPwd, setShowPwd] = useState(false);
  const [success, setSuccess] = useState("");

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = "Name is required.";
    if (!form.email.trim()) e.email = "Email is required.";
    else if (!/\S+@\S+\.\S+/.test(form.email)) e.email = "Invalid email format.";
    if (!form.password) e.password = "Password is required.";
    else if (form.password.length < 6) e.password = "Min 6 characters.";
    if (form.password !== form.confirm) e.confirm = "Passwords do not match.";
    return e;
  };

  const handleChange = (e) => {
    setForm((p) => ({ ...p, [e.target.name]: e.target.value }));
    setErrors((p) => ({ ...p, [e.target.name]: "" }));
    setSuccess("");
  };

  const handleSubmit = async (ev) => {
    ev.preventDefault();
    const e = validate();
    if (Object.keys(e).length) { setErrors(e); return; }
    setLoading(true);
    try {
      const res = await fetch("http://127.0.0.1:8000/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: form.name, email: form.email, password: form.password, role: form.role }),
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        setErrors({ email: data.error || "Registration failed." });
      } else {
        setSuccess("Account created! Redirecting to login…");
        setTimeout(() => navigate("/login"), 1800);
      }
    } catch {
      setSuccess("Account created (demo mode)! Redirecting…");
      setTimeout(() => navigate("/login"), 1800);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-bg">
      <div className="auth-card auth-card-wide">
        <div className="auth-logo">
          <div className="auth-logo-icon">🎓</div>
          <h1 className="auth-brand">Smart Exam System</h1>
          <p className="auth-tagline">Create your account</p>
        </div>

        <form onSubmit={handleSubmit} className="auth-form" noValidate>
          {success && <div className="auth-success">✅ {success}</div>}

          <div className="auth-field">
            <label>Full Name</label>
            <input name="name" placeholder="Your full name" value={form.name} onChange={handleChange} autoFocus />
            {errors.name && <span className="auth-field-err">{errors.name}</span>}
          </div>

          <div className="auth-field">
            <label>Email Address</label>
            <input type="email" name="email" placeholder="you@example.com" value={form.email} onChange={handleChange} />
            {errors.email && <span className="auth-field-err">{errors.email}</span>}
          </div>

          <div className="auth-field">
            <label>I am a</label>
            <div className="auth-role-group">
              <button type="button" className={`auth-role-btn${form.role === "student" ? " selected" : ""}`}
                onClick={() => setForm(p => ({ ...p, role: "student" }))}>
                <span className="role-icon">🎓</span> Student
              </button>
              <button type="button" className={`auth-role-btn${form.role === "teacher" ? " selected" : ""}`}
                onClick={() => setForm(p => ({ ...p, role: "teacher" }))}>
                <span className="role-icon">👨‍🏫</span> Teacher
              </button>
            </div>
          </div>

          <div className="auth-field">
            <label>Password</label>
            <div className="auth-pwd-wrap">
              <input type={showPwd ? "text" : "password"} name="password" placeholder="Min 6 characters"
                value={form.password} onChange={handleChange} />
              <button type="button" className="auth-eye" onClick={() => setShowPwd(p => !p)}>
                {showPwd ? "🙈" : "👁"}
              </button>
            </div>
            {errors.password && <span className="auth-field-err">{errors.password}</span>}
          </div>

          <div className="auth-field">
            <label>Confirm Password</label>
            <input type="password" name="confirm" placeholder="Re-enter password" value={form.confirm} onChange={handleChange} />
            {errors.confirm && <span className="auth-field-err">{errors.confirm}</span>}
          </div>

          <button type="submit" className="auth-btn" disabled={loading}>
            {loading ? "Creating account…" : "Create Account"}
          </button>
        </form>

        <p className="auth-switch">
          Already have an account? <Link to="/login">Sign in</Link>
        </p>
      </div>
    </div>
  );
}

export default Register;
