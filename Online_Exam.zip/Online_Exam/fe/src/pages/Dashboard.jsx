import { useEffect, useState } from "react";
import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";
import "../styles/Dashboard.css";

function Dashboard(){

const [totalStudents,setTotalStudents] = useState(0)
const [totalExams,setTotalExams] = useState(0)
const [totalQuestions,setTotalQuestions] = useState(0)
const [recentExams,setRecentExams] = useState([])

useEffect(()=>{

// BACKEND MODE ✅

fetch("http://127.0.0.1:8000/get_users")
.then(res=>res.json())
.then(data=>{
setTotalStudents(data.length)
})

fetch("http://127.0.0.1:8000/get_exam")
.then(res=>res.json())
.then(data=>{
setTotalExams(data.length)
setRecentExams(data.slice(0,4))
})

fetch("http://127.0.0.1:8000/get_quiz")
.then(res=>res.json())
.then(data=>{
setTotalQuestions(data.length)
})

},[])

/*
// FRONTEND (DUMMY MODE) ❌

useEffect(()=>{

const users = [
{ id:1, name:"Arun" },
{ id:2, name:"Priya" },
{ id:3, name:"Rahul" },
{ id:4, name:"Sneha" },
{ id:5, name:"Kumar" }
]

const exams = [
{ id:1, exam_name:"Mid Term Exam", subject_name:"Mathematics", duration:60 },
{ id:2, exam_name:"Unit Test", subject_name:"Physics", duration:45 },
{ id:3, exam_name:"Semester Exam", subject_name:"Chemistry", duration:90 },
{ id:4, exam_name:"Mock Test", subject_name:"Computer Science", duration:60 },
{ id:5, exam_name:"Final Exam", subject_name:"Biology", duration:120 }
]

const questions = [
{ id:1 }, { id:2 }, { id:3 },
{ id:4 }, { id:5 }, { id:6 }, { id:7 }
]

setTotalStudents(users.length)
setTotalExams(exams.length)
setTotalQuestions(questions.length)
setRecentExams(exams.slice(0,4))

},[])
*/

return(

<div className="dashboard-container">

<Sidebar/>

<div className="dashboard-main">

<Navbar/>

<div className="dashboard-content">

<h2>Dashboard</h2>
<p className="subtitle">Overview of your examination system</p>

<div className="stats">

<div className="stat-card">
<h4>Total Students</h4>
<h1>{totalStudents}</h1>
</div>

<div className="stat-card">
<h4>Active Exams</h4>
<h1>{totalExams}</h1>
</div>

<div className="stat-card">
<h4>Questions</h4>
<h1>{totalQuestions}</h1>
</div>

<div className="stat-card">
<h4>Avg Score</h4>
<h1>78%</h1>
</div>

</div>

<div className="recent-exams">

<h3 className="table-title">Recent Exams</h3>

<table className="exam-table">

<thead>
<tr>
<th>Exam Title</th>
<th>Subject</th>
<th>Status</th>
<th>Duration</th>
</tr>
</thead>

<tbody>

{recentExams.map((exam)=>(
<tr key={exam.id}>
<td>{exam.exam_name}</td>
<td>{exam.subject_name}</td>
<td>
<span className="status active">
Active
</span>
</td>
<td>{exam.duration} min</td>
</tr>
))}

</tbody>

</table>

</div>

</div>

</div>

</div>

)

}

export default Dashboard;