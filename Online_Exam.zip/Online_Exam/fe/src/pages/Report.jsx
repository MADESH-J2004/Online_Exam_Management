import { useEffect, useState, useMemo } from "react";
import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";
import "./Report.css";

const MEDAL = { 1: "🥇", 2: "🥈", 3: "🥉" };

function gradeColor(g) {
  if (g === "A+") return "#10b981";
  if (g && g.startsWith("A")) return "#22c55e";
  if (g && g.startsWith("B")) return "#3b82f6";
  if (g && g.startsWith("C")) return "#f59e0b";
  if (g && g.startsWith("D")) return "#f97316";
  return "#ef4444";
}

function pctBar(pct) {
  const color = pct >= 80 ? "#10b981" : pct >= 60 ? "#f59e0b" : pct >= 40 ? "#f97316" : "#ef4444";
  return (
    <div style={{ display:"flex", alignItems:"center", gap:8, minWidth:160 }}>
      <div style={{ flex:1, height:8, background:"#e5e7eb", borderRadius:4, overflow:"hidden" }}>
        <div style={{ width:`${Math.min(pct,100)}%`, height:"100%", background:color, borderRadius:4 }}/>
      </div>
      <span style={{ minWidth:44, fontSize:13, fontWeight:600, color }}>{pct.toFixed(1)}%</span>
    </div>
  );
}

function getGrade(pct) {
  if (pct >= 95) return "A+";
  if (pct >= 85) return "A";
  if (pct >= 75) return "B+";
  if (pct >= 65) return "B";
  if (pct >= 55) return "C";
  if (pct >= 45) return "D";
  return "F";
}

function Report() {
  const [results, setResults]   = useState([]);
  const [summary, setSummary]   = useState(null);
  const [loading, setLoading]   = useState(true);
  const [search, setSearch]     = useState("");
  const [filterStatus, setFilterStatus]   = useState("All");
  const [filterSubject, setFilterSubject] = useState("All");
  const [sortKey, setSortKey]   = useState("percentage");

  useEffect(() => {
    Promise.all([
      fetch("http://127.0.0.1:8000/results").then(r => r.json()),
      fetch("http://127.0.0.1:8000/results/summary").then(r => r.json()),
    ])
      .then(([res, sum]) => { setResults(Array.isArray(res) ? res : []); setSummary(sum); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const subjects = useMemo(() => {
    const s = new Set(results.map(r => r.subject_name).filter(Boolean));
    return ["All", ...Array.from(s).sort()];
  }, [results]);

  const filtered = useMemo(() => {
    return results
      .filter(r => {
        const name = (r.user_name || "").toLowerCase();
        const exam = (r.exam_name || "").toLowerCase();
        const matchSearch  = !search || name.includes(search.toLowerCase()) || exam.includes(search.toLowerCase());
        const matchStatus  = filterStatus  === "All" || r.result_status === filterStatus;
        const matchSubject = filterSubject === "All" || r.subject_name  === filterSubject;
        return matchSearch && matchStatus && matchSubject;
      })
      .sort((a, b) => {
        if (sortKey === "percentage") return b.percentage - a.percentage;
        if (sortKey === "name")       return (a.user_name||"").localeCompare(b.user_name||"");
        if (sortKey === "date")       return new Date(b.result_date||0) - new Date(a.result_date||0);
        return 0;
      });
  }, [results, search, filterStatus, filterSubject, sortKey]);

  return (
    <div className="dashboard-container">
      <Sidebar />
      <div className="dashboard-main">
        <Navbar />
        <div className="report-page">
          <h2 className="report-title">Results &amp; Reports</h2>
          <p className="report-subtitle">Sorted by percentage</p>

          {summary && (
            <div className="report-stats">
              {[
                { icon:"📋", val:summary.total_results,          label:"Total Attempts", cls:"blue"   },
                { icon:"✅", val:summary.passed,                 label:"Passed",         cls:"green"  },
                { icon:"❌", val:summary.failed,                 label:"Failed",         cls:"red"    },
                { icon:"📊", val:summary.avg_percentage + "%",   label:"Avg Score",      cls:"orange" },
                { icon:"🏆", val:summary.pass_rate + "%",        label:"Pass Rate",      cls:"purple" },
                { icon:"⭐", val:Number(summary.top_score||0).toFixed(1)+"%", label:"Top Score", cls:"teal" },
              ].map(s => (
                <div key={s.label} className={`report-stat-card ${s.cls}`}>
                  <span className="rs-icon">{s.icon}</span>
                  <div><div className="rs-val">{s.val}</div><div className="rs-label">{s.label}</div></div>
                </div>
              ))}
            </div>
          )}

          <div className="report-filters">
            <input className="report-search" placeholder="🔍 Search student or exam…" value={search} onChange={e => setSearch(e.target.value)}/>
            <select className="report-select" value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
              <option value="All">All Status</option><option value="PASS">Pass</option><option value="FAIL">Fail</option>
            </select>
            <select className="report-select" value={filterSubject} onChange={e => setFilterSubject(e.target.value)}>
              {subjects.map(s => <option key={s}>{s}</option>)}
            </select>
            <select className="report-select" value={sortKey} onChange={e => setSortKey(e.target.value)}>
              <option value="percentage">Sort: Score</option><option value="name">Sort: Name</option><option value="date">Sort: Date</option>
            </select>
            <span className="report-count">{filtered.length} result{filtered.length!==1?"s":""}</span>
          </div>

          <div className="report-table-wrap">
            {loading ? (
              <div className="report-empty">⏳ Loading results…</div>
            ) : filtered.length === 0 ? (
              <div className="report-empty">No results found.</div>
            ) : (
              <table className="report-table">
                <thead>
                  <tr>
                    <th>RANK</th><th>STUDENT</th><th>EXAM</th><th>SUBJECT</th>
                    <th>CORRECT</th><th>WRONG</th><th>SCORE</th><th>PERCENTAGE</th>
                    <th>GRADE</th><th>STATUS</th><th>DATE</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((r, idx) => {
                    const rank  = idx + 1;
                    const pct   = Number(r.percentage || 0);
                    const grade = getGrade(pct);
                    const dateStr = r.result_date
                      ? new Date(r.result_date).toLocaleDateString("en-US", { month:"numeric", day:"numeric", year:"numeric" })
                      : "—";
                    return (
                      <tr key={r.result_id || idx} className={r.result_status==="FAIL"?"row-fail":""}>
                        <td>
                          {rank<=3
                            ? <span style={{fontSize:22}}>{MEDAL[rank]}</span>
                            : <span className="rank-badge">{rank}</span>}
                        </td>
                        <td className="student-name">{r.user_name || `User #${r.user_id}`}</td>
                        <td>{r.exam_name||"—"}</td>
                        <td className="subject-cell">{r.subject_name||"—"}</td>
                        <td className="correct-cell">{r.correct_answers??0}</td>
                        <td className="wrong-cell">{r.wrong_answers??0}</td>
                        <td>{r.correct_answers??0}/{r.total_quiz??0}</td>
                        <td>{pctBar(pct)}</td>
                        <td>
                          <span className="grade-badge" style={{background:gradeColor(grade)+"22",color:gradeColor(grade),border:`1px solid ${gradeColor(grade)}44`}}>
                            {grade}
                          </span>
                        </td>
                        <td>
                          <span className={`status-badge ${r.result_status==="PASS"?"pass":"fail"}`}>
                            {r.result_status}
                          </span>
                        </td>
                        <td className="date-cell">{dateStr}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Report;
