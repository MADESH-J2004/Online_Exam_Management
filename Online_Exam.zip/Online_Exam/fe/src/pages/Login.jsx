import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import "./Auth.css";

function Login() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "", role: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPwd, setShowPwd] = useState(false);

  const handleChange = (e) => {
    setForm((p) => ({ ...p, [e.target.name]: e.target.value }));
    setError("");
  };

  const selectRole = (role) => {
    setForm((p) => ({ ...p, role }));
    setError("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.email.trim() || !form.password.trim()) {
      setError("Please enter your email and password.");
      return;
    }
    if (!form.role) {
      setError("Please select your role (Student or Teacher).");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("http://127.0.0.1:8000/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: form.email, password: form.password }),
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        setError(data.error || "Invalid email or password.");
      } else {
        // Enforce role match
        const serverRole = (data.role || "").toLowerCase();
        const selectedRole = form.role.toLowerCase();
        if (serverRole !== selectedRole && serverRole !== "admin") {
          setError(`This account is registered as "${serverRole}", not "${selectedRole}".`);
          setLoading(false);
          return;
        }
        localStorage.setItem("exam_user", JSON.stringify(data));
        redirectByRole(data.role);
      }
    } catch {
      // Demo fallback
      if (form.email === "admin@exam.com" && form.password === "admin123") {
        const user = { user_id: 1, name: "Admin", email: form.email, role: "admin" };
        localStorage.setItem("exam_user", JSON.stringify(user));
        redirectByRole("admin");
      } else {
        setError("Cannot connect to server. Use admin@exam.com / admin123 for demo.");
      }
    } finally {
      setLoading(false);
    }
  };

  const redirectByRole = (role) => {
    const r = (role || "").toLowerCase();
    if (r === "admin") navigate("/");
    else if (r === "teacher") navigate("/teacher");
    else navigate("/student");
  };

  return (
    <div className="auth-bg">
      <div className="auth-card">
        <div className="auth-logo">
          <div className="auth-logo-icon">📝</div>
          <h1 className="auth-brand">Smart Exam System</h1>
          <p className="auth-tagline">Sign in to your account</p>
        </div>

        <form onSubmit={handleSubmit} className="auth-form" noValidate>
          {error && <div className="auth-error">⚠ {error}</div>}

          <div className="auth-field">
            <label>I am a</label>
            <div className="auth-role-group">
              <button
                type="button"
                className={`auth-role-btn${form.role === "student" ? " selected" : ""}`}
                onClick={() => selectRole("student")}
              >
                <span className="role-icon">🎓</span>
                Student
              </button>
              <button
                type="button"
                className={`auth-role-btn${form.role === "teacher" ? " selected" : ""}`}
                onClick={() => selectRole("teacher")}
              >
                <span className="role-icon">👨‍🏫</span>
                Teacher
              </button>
            </div>
          </div>

          <div className="auth-field">
            <label>Email Address</label>
            <input
              type="email"
              name="email"
              placeholder="you@example.com"
              value={form.email}
              onChange={handleChange}
              autoComplete="email"
            />
          </div>

          <div className="auth-field">
            <label>
              Password
              <span className="auth-forgot-inline">
                <Link to="/forgot-password">Forgot password?</Link>
              </span>
            </label>
            <div className="auth-pwd-wrap">
              <input
                type={showPwd ? "text" : "password"}
                name="password"
                placeholder="Enter your password"
                value={form.password}
                onChange={handleChange}
                autoComplete="current-password"
              />
              <button type="button" className="auth-eye" onClick={() => setShowPwd((p) => !p)}>
                {showPwd ? "🙈" : "👁"}
              </button>
            </div>
          </div>

          <button type="submit" className="auth-btn" disabled={loading}>
            {loading ? "Signing in…" : "Sign In"}
          </button>
        </form>

        <p className="auth-switch">
          Don't have an account? <Link to="/register">Create account</Link>
        </p>

        <div className="auth-demo">
          <span>Demo credentials:</span>{" "}
          <code>admin@exam.com</code> / <code>admin123</code>
        </div>
      </div>
    </div>
  );
}

export default Login;
