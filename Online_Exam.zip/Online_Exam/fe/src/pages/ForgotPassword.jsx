import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Auth.css";

function ForgotPassword() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1); // 1=email, 2=newpwd, 3=done
  const [email, setEmail] = useState("");
  const [newPwd, setNewPwd] = useState("");
  const [confirmPwd, setConfirmPwd] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPwd, setShowPwd] = useState(false);

  // Step 1: Verify email exists
  const handleVerifyEmail = async (e) => {
    e.preventDefault();
    setError("");
    if (!email.trim() || !/\S+@\S+\.\S+/.test(email)) {
      setError("Enter a valid email address.");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("http://127.0.0.1:8000/check-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        setError(data.error || "Email not found.");
      } else {
        setStep(2);
      }
    } catch (err) {
      setError("Network error. Please check your connection and try again.");
    } finally {
      setLoading(false);
    }
  };

  // Step 2: Reset password directly
  const handleReset = async (e) => {
    e.preventDefault();
    setError("");
    if (!newPwd || newPwd.length < 6) { setError("Password must be at least 6 characters."); return; }
    if (newPwd !== confirmPwd) { setError("Passwords do not match."); return; }
    setLoading(true);
    try {
      const res = await fetch("http://127.0.0.1:8000/reset-password-direct", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, new_password: newPwd }),
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        setError(data.error || "Reset failed.");
      } else {
        setStep(3);
      }
    } catch (err) {
      setError("Network error. Please check your connection and try again.");
    } finally {
      setLoading(false);
    }
  };

  const steps = ["Email", "New Password"];

  return (
    <div className="auth-bg">
      <div className="auth-card">
        {/* Progress steps */}
        <div className="auth-steps">
          {steps.map((label, i) => (
            <div
              key={i}
              className={`auth-step ${step > i + 1 ? "done" : step === i + 1 ? "active" : ""}`}
            >
              <div className="auth-step-circle">
                {step > i + 1 ? "✓" : i + 1}
              </div>
              <span>{label}</span>
            </div>
          ))}
        </div>

        {/* Step 1: Email */}
        {step === 1 && (
          <>
            <div className="auth-logo">
              <div className="auth-logo-icon">🔑</div>
              <h1 className="auth-brand">Forgot Password</h1>
              <p className="auth-tagline">Enter your registered email to continue</p>
            </div>
            <form onSubmit={handleVerifyEmail} className="auth-form">
              {error && <div className="auth-error">⚠ {error}</div>}
              <div className="auth-field">
                <label>Email Address</label>
                <input
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => { setEmail(e.target.value); setError(""); }}
                  autoFocus
                />
              </div>
              <button type="submit" className="auth-btn" disabled={loading}>
                {loading ? "Verifying…" : "Continue"}
              </button>
            </form>
            <p className="auth-switch">
              Remember your password? <Link to="/login">Sign in</Link>
            </p>
          </>
        )}

        {/* Step 2: New Password */}
        {step === 2 && (
          <>
            <div className="auth-logo">
              <div className="auth-logo-icon">🔒</div>
              <h1 className="auth-brand">New Password</h1>
              <p className="auth-tagline">Choose a strong new password for <strong>{email}</strong></p>
            </div>
            <form onSubmit={handleReset} className="auth-form">
              {error && <div className="auth-error">⚠ {error}</div>}
              <div className="auth-field">
                <label>New Password</label>
                <div className="auth-pwd-wrap">
                  <input
                    type={showPwd ? "text" : "password"}
                    placeholder="Min 6 characters"
                    value={newPwd}
                    onChange={(e) => { setNewPwd(e.target.value); setError(""); }}
                    autoFocus
                  />
                  <button type="button" className="auth-eye" onClick={() => setShowPwd((p) => !p)}>
                    {showPwd ? "🙈" : "👁"}
                  </button>
                </div>
              </div>
              <div className="auth-field">
                <label>Confirm New Password</label>
                <input
                  type="password"
                  placeholder="Re-enter new password"
                  value={confirmPwd}
                  onChange={(e) => { setConfirmPwd(e.target.value); setError(""); }}
                />
              </div>
              <button type="submit" className="auth-btn" disabled={loading}>
                {loading ? "Resetting…" : "Reset Password"}
              </button>
              <button type="button" className="auth-btn-ghost" onClick={() => { setStep(1); setError(""); }}>
                ← Change Email
              </button>
            </form>
          </>
        )}

        {/* Step 3: Done */}
        {step === 3 && (
          <div className="auth-success-screen">
            <div className="auth-success-icon">🎉</div>
            <h2>Password Reset!</h2>
            <p>Your password has been updated successfully.</p>
            <Link to="/login" className="auth-btn" style={{ marginTop: 24 }}>
              Back to Login
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}

export default ForgotPassword;
