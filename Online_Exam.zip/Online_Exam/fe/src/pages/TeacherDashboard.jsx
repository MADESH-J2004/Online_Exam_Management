import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import "../styles/Dashboard.css";

function TeacherDashboard() {
  const navigate = useNavigate();
  const userRaw = localStorage.getItem("exam_user");
  const user = userRaw ? JSON.parse(userRaw) : null;
  const [exams, setExams] = useState([]);
  const [results, setResults] = useState([]);
  const [students, setStudents] = useState([]);
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { navigate("/login"); return; }

    Promise.all([
      fetch("http://127.0.0.1:8000/get_exam").then(r => r.json()).catch(() => []),
      fetch("http://127.0.0.1:8000/results").then(r => r.json()).catch(() => []),
      fetch("http://127.0.0.1:8000/get_users").then(r => r.json()).catch(() => []),
      fetch("http://127.0.0.1:8000/get_quiz").then(r => r.json()).catch(() => []),
    ]).then(([examData, resultData, userData, qData]) => {
      setExams(Array.isArray(examData) ? examData : []);
      setResults(Array.isArray(resultData) ? resultData : []);
      setStudents((Array.isArray(userData) ? userData : []).filter(u => u.role === "student" || u.role === "Student"));
      setQuestions(Array.isArray(qData) ? qData : []);
      setLoading(false);
    });
  }, []);

  const avgScore = results.length
    ? Math.round(results.reduce((s, r) => s + (r.percentage || 0), 0) / results.length)
    : 0;

  return (
    <div className="dashboard-container">
      <div className="teacher-sidebar">
        <h2 className="logo">🏫 Smart Exam</h2>
        <ul>
          <li className="active">🏠 Dashboard</li>
          <li onClick={() => navigate("/exams")}>📋 Manage Exams</li>
          <li onClick={() => navigate("/questions")}>❓ Question Bank</li>
          <li onClick={() => navigate("/results")}>📊 Results</li>
          <li onClick={() => navigate("/evaluation")}>✅ Evaluation</li>
        </ul>
        <div className="sidebar-user">
          <div className="sidebar-avatar">{user?.name?.[0]?.toUpperCase() || "T"}</div>
          <div>
            <div className="sidebar-name">{user?.name}</div>
            <div className="sidebar-role">Teacher</div>
          </div>
        </div>
      </div>

      <div className="dashboard-main">
        <Navbar />
        <div className="dashboard-content">
          <h2>Teacher Dashboard</h2>
          <p className="subtitle">Manage exams, questions, and monitor student performance.</p>

          <div className="stats">
            <div className="stat-card">
              <h4>Total Students</h4>
              <h1>{students.length}</h1>
              <span className="stat-sub">Registered</span>
            </div>
            <div className="stat-card">
              <h4>Active Exams</h4>
              <h1>{exams.length}</h1>
              <span className="stat-sub">Scheduled</span>
            </div>
            <div className="stat-card">
              <h4>Questions Bank</h4>
              <h1>{questions.length}</h1>
              <span className="stat-sub">Total questions</span>
            </div>
            <div className="stat-card">
              <h4>Avg Performance</h4>
              <h1>{avgScore}%</h1>
              <span className="stat-sub">All students</span>
            </div>
          </div>

          <div className="two-col">
            {/* Exams */}
            <div className="section-card">
              <div className="section-header">
                <h3>Recent Exams</h3>
                <button className="view-all-btn" onClick={() => navigate("/exams")}>View All</button>
              </div>
              {loading ? <p className="loading-txt">Loading...</p> :
                exams.length === 0
                  ? <p className="empty-txt">No exams created yet.</p>
                  : exams.slice(0, 4).map(exam => (
                    <div key={exam.id} className="exam-item">
                      <div className="exam-item-info">
                        <div className="exam-item-name">{exam.exam_name}</div>
                        <div className="exam-item-sub">{exam.subject_name} • {exam.duration} min</div>
                      </div>
                      <button
                        className="view-btn"
                        onClick={() => navigate(`/exams/${exam.id}`)}
                      >
                        View
                      </button>
                    </div>
                  ))
              }
            </div>

            {/* Results */}
            <div className="section-card">
              <div className="section-header">
                <h3>Recent Results</h3>
                <button className="view-all-btn" onClick={() => navigate("/results")}>View All</button>
              </div>
              {results.length === 0
                ? <p className="empty-txt">No results yet.</p>
                : results.slice(0, 4).map(r => (
                  <div key={r.result_id} className="result-item">
                    <div className="result-item-info">
                      <div className="result-item-name">{r.user_name || "Student"}</div>
                      <div className="result-item-sub">{r.exam_name}</div>
                    </div>
                    <div className={`result-badge ${r.result_status === "PASS" ? "pass" : "fail"}`}>
                      {r.percentage}% • {r.result_status}
                    </div>
                  </div>
                ))
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default TeacherDashboard;
