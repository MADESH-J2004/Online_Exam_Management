import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import "../styles/Dashboard.css";

function StudentExams() {
  const navigate = useNavigate();
  const userRaw = localStorage.getItem("exam_user");
  const user = userRaw ? JSON.parse(userRaw) : null;
  const [exams, setExams] = useState([]);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { navigate("/login"); return; }
    Promise.all([
      fetch("http://127.0.0.1:8000/get_exam").then(r => r.json()).catch(() => []),
      fetch("http://127.0.0.1:8000/results").then(r => r.json()).catch(() => []),
    ]).then(([examData, resultData]) => {
      setExams(Array.isArray(examData) ? examData : []);
      const myResults = Array.isArray(resultData)
        ? resultData.filter(r => r.user_id === user?.user_id)
        : [];
      setResults(myResults);
      setLoading(false);
    });
  }, []);

  const attemptedIds = new Set(results.map(r => r.exam_id));

  return (
    <div className="dashboard-container">
      <div className="student-sidebar">
        <h2 className="logo">📚 Smart Exam</h2>
        <ul>
          <li onClick={() => navigate("/student")}>🏠 Dashboard</li>
          <li className="active">📋 Available Exams</li>
          <li onClick={() => navigate("/student/results")}>📊 My Results</li>
        </ul>
      </div>
      <div className="dashboard-main">
        <Navbar />
        <div className="dashboard-content">
          <h2>Available Exams</h2>
          <p className="subtitle">Select an exam to begin.</p>
          {loading ? <p>Loading...</p> : (
            <div className="exam-cards-grid">
              {exams.map(exam => {
                const done = attemptedIds.has(exam.id);
                const myResult = results.find(r => r.exam_id === exam.id);
                return (
                  <div key={exam.id} className={`exam-card ${done ? "exam-card-done" : ""}`}>
                    <div className="exam-card-header">
                      <span className="exam-card-subject">{exam.subject_name}</span>
                      {done && <span className="badge-done">Completed</span>}
                    </div>
                    <h3 className="exam-card-name">{exam.exam_name}</h3>
                    <div className="exam-card-meta">
                      <span>⏱ {exam.duration} min</span>
                      <span>📝 {exam.total_marks} marks</span>
                    </div>
                    {done && myResult && (
                      <div className={`exam-card-result ${myResult.result_status === "PASS" ? "pass" : "fail"}`}>
                        Score: {myResult.percentage}% — {myResult.result_status}
                      </div>
                    )}
                    {!done && (
                      <button className="start-btn full" onClick={() => navigate(`/exam/${exam.id}`)}>
                        Start Exam
                      </button>
                    )}
                  </div>
                );
              })}
              {exams.length === 0 && <p className="empty-txt">No exams available.</p>}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default StudentExams;
