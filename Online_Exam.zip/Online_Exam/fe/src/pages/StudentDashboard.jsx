import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import "../styles/Dashboard.css";

function StudentDashboard() {
  const navigate = useNavigate();
  const userRaw = localStorage.getItem("exam_user");
  const user = userRaw ? JSON.parse(userRaw) : null;
  const [exams, setExams] = useState([]);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { navigate("/login"); return; }

    Promise.all([
      fetch("http://127.0.0.1:8000/get_exam").then(r => r.json()).catch(() => []),
      fetch(`http://127.0.0.1:8000/results/user/${user.user_id}`).then(r => r.json()).catch(() => []),
    ]).then(([examData, resultData]) => {
      setExams(Array.isArray(examData) ? examData : []);
      setResults(Array.isArray(resultData) ? resultData : []);
      setLoading(false);
    });
  }, []);

  const attemptedIds = new Set(results.map(r => r.exam_id));
  const availableExams = exams.filter(e => !attemptedIds.has(e.id));
  const avgScore = results.length
    ? Math.round(results.reduce((s, r) => s + (r.percentage || 0), 0) / results.length)
    : 0;

  return (
    <div className="dashboard-container">
      <div className="student-sidebar">
        <h2 className="logo">📚 Smart Exam</h2>
        <ul>
          <li className="active">🏠 Dashboard</li>
          <li onClick={() => navigate("/student/exams")}>📋 Available Exams</li>
          <li onClick={() => navigate("/student/results")}>📊 My Results</li>
        </ul>
        <div className="sidebar-user">
          <div className="sidebar-avatar">{user?.name?.[0]?.toUpperCase() || "S"}</div>
          <div>
            <div className="sidebar-name">{user?.name}</div>
            <div className="sidebar-role">Student</div>
          </div>
        </div>
      </div>

      <div className="dashboard-main">
        <Navbar />
        <div className="dashboard-content">
          <h2>Student Dashboard</h2>
          <p className="subtitle">Welcome back, {user?.name}! Here's your exam overview.</p>

          <div className="stats">
            <div className="stat-card">
              <h4>Available Exams</h4>
              <h1>{availableExams.length}</h1>
              <span className="stat-sub">Ready to attempt</span>
            </div>
            <div className="stat-card">
              <h4>Exams Taken</h4>
              <h1>{results.length}</h1>
              <span className="stat-sub">Completed</span>
            </div>
            <div className="stat-card">
              <h4>Avg Score</h4>
              <h1>{avgScore}%</h1>
              <span className="stat-sub">Overall performance</span>
            </div>
            <div className="stat-card">
              <h4>Passed</h4>
              <h1>{results.filter(r => r.result_status === "PASS").length}</h1>
              <span className="stat-sub">Out of {results.length}</span>
            </div>
          </div>

          <div className="two-col">
            {/* Available Exams */}
            <div className="section-card">
              <div className="section-header">
                <h3>Available Exams</h3>
                <button className="view-all-btn" onClick={() => navigate("/student/exams")}>View All</button>
              </div>
              {loading ? <p className="loading-txt">Loading...</p> :
                availableExams.length === 0
                  ? <p className="empty-txt">No new exams available.</p>
                  : availableExams.slice(0, 4).map(exam => (
                    <div key={exam.id} className="exam-item">
                      <div className="exam-item-info">
                        <div className="exam-item-name">{exam.exam_name}</div>
                        <div className="exam-item-sub">{exam.subject_name} • {exam.duration} min</div>
                      </div>
                      <button
                        className="start-btn"
                        onClick={() => navigate(`/exam/${exam.id}`)}
                      >
                        Start
                      </button>
                    </div>
                  ))
              }
            </div>

            {/* Recent Results */}
            <div className="section-card">
              <div className="section-header">
                <h3>Recent Results</h3>
                <button className="view-all-btn" onClick={() => navigate("/student/results")}>View All</button>
              </div>
              {results.length === 0
                ? <p className="empty-txt">No results yet.</p>
                : results.slice(0, 4).map(r => (
                  <div key={r.result_id} className="result-item">
                    <div className="result-item-info">
                      <div className="result-item-name">{r.exam_name || "Exam"}</div>
                      <div className="result-item-sub">{r.subject_name}</div>
                    </div>
                    <div className={`result-badge ${r.result_status === "PASS" ? "pass" : "fail"}`}>
                      {r.percentage}% • {r.result_status}
                    </div>
                  </div>
                ))
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default StudentDashboard;
