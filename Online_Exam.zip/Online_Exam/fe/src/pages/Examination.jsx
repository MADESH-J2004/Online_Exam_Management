import { useEffect, useRef, useState, useCallback } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";

function Examination() {
  const _examUser = (() => { try { return JSON.parse(localStorage.getItem("exam_user") || "{}"); } catch { return {}; } })();
  const USER_ID = _examUser.user_id || 0;
  const STUDENT_NAME = _examUser.name || "Student User";

  const { examId } = useParams();
  const navigate = useNavigate();
  const location = useLocation();

  const [exam, setExam] = useState(location.state?.exam || null);
  const [questions, setQuestions] = useState(location.state?.questions || []);
  const [loadingQ, setLoadingQ] = useState(!location.state?.questions);
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState({});
  const [timeLeft, setTimeLeft] = useState((location.state?.exam?.duration || 30) * 60);
  const [submitted, setSubmitted] = useState(false);
  const [result, setResult] = useState(null);

  // Camera & Detection
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const detectRef = useRef(null);
  const [cameraReady, setCameraReady] = useState(false);
  const [modelsReady, setModelsReady] = useState(false);
  const [loadingModels, setLoadingModels] = useState(true);
  const [faceStatus, setFaceStatus] = useState("⏳ Loading face models...");
  const [faceOk, setFaceOk] = useState(true);
  const [warnings, setWarnings] = useState([]);
  const [liveAlert, setLiveAlert] = useState(null);
  const warnCount = useRef(0);
  const noFaceFrames = useRef(0);
  const lastWarnTime = useRef(0);

  // ── Load face-api models ──
  useEffect(() => {
    const s = document.createElement("script");
    s.src = "https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js";
    s.onload = loadModels;
    document.head.appendChild(s);
    return () => { stopCamera(); clearInterval(detectRef.current); };
  }, []);

  const loadModels = async () => {
    const URL = "https://cdn.jsdelivr.net/npm/@vladmandic/face-api/model";
    try {
      await Promise.all([
        window.faceapi.nets.tinyFaceDetector.loadFromUri(URL),
        window.faceapi.nets.faceLandmark68Net.loadFromUri(URL),
      ]);
      setModelsReady(true);
      setLoadingModels(false);
      setFaceStatus("✅ Ready — click Start Camera");
    } catch {
      setLoadingModels(false);
      setFaceStatus("⚠ Model load failed");
    }
  };

  // ── Fetch exam + questions in PARALLEL (fast) ──
  useEffect(() => {
    const needExam = !exam;
    const needQuestions = !location.state?.questions;

    const promises = [];

    if (needExam) {
      promises.push(
        fetch(`http://127.0.0.1:8000/get_exam/${examId}`)
          .then(r => r.json())
          .then(data => {
            setExam(data);
            if (data?.duration) setTimeLeft(data.duration * 60);
          })
          .catch(() => {})
      );
    }

    if (needQuestions) {
      promises.push(
        fetch(`http://127.0.0.1:8000/get_quiz/${examId}`)
          .then(r => r.json())
          .then(data => {
            setQuestions(Array.isArray(data) ? data : []);
            setLoadingQ(false);
          })
          .catch(() => setLoadingQ(false))
      );
    }

    // Run both fetches at the same time
    if (promises.length > 0) {
      Promise.all(promises).catch(() => setLoadingQ(false));
    }
  }, [examId]);

  // ── Timer ──
  useEffect(() => {
    if (submitted) return;
    const t = setInterval(() => {
      setTimeLeft(p => {
        if (p <= 1) { clearInterval(t); handleSubmit(); return 0; }
        return p - 1;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [submitted]);

  const fmt = s => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;

  // ── Camera ──
  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 320, height: 240, facingMode: "user" }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setCameraReady(true);
      setFaceStatus("📸 Camera on — detecting...");
    } catch {
      setFaceStatus("❌ Camera access denied");
    }
  };

  const stopCamera = () => {
    streamRef.current?.getTracks().forEach(t => t.stop());
    clearInterval(detectRef.current);
    setCameraReady(false);
  };

  // ── Log warning to backend (fire-and-forget) ──
  const logWarning = (activity, severity) => {
    fetch("http://127.0.0.1:8000/log_activity", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        user_name: STUDENT_NAME,
        exam_name: exam?.exam_name || "Exam",
        activity,
        severity
      }),
    }).catch(() => {});
  };

  // ── Throttled warning ──
  const triggerWarning = useCallback((msg, severity = "HIGH") => {
    const now = Date.now();
    if (now - lastWarnTime.current < 5000) return;
    lastWarnTime.current = now;
    warnCount.current += 1;
    const entry = { id: now, msg, severity, time: new Date().toLocaleTimeString() };
    setWarnings(p => [entry, ...p].slice(0, 15));
    setLiveAlert(entry);
    logWarning(msg, severity);
    setTimeout(() => setLiveAlert(null), 3500);
  }, [exam]);

  // ── Face detection (no canvas drawing) ──
  const startDetection = useCallback(() => {
    if (detectRef.current) clearInterval(detectRef.current);

    detectRef.current = setInterval(async () => {
      if (!videoRef.current || !window.faceapi || !modelsReady) return;
      const video = videoRef.current;
      if (video.readyState < 2 || video.paused) return;

      try {
        const detections = await window.faceapi
          .detectAllFaces(video, new window.faceapi.TinyFaceDetectorOptions({
            scoreThreshold: 0.45,
            inputSize: 160  // smaller = FASTER detection
          }))
          .withFaceLandmarks();

        // No face
        if (detections.length === 0) {
          noFaceFrames.current += 1;
          if (noFaceFrames.current >= 4) {
            setFaceStatus("🚨 No face detected!");
            setFaceOk(false);
            triggerWarning("No face detected — student may have left", "HIGH");
          }
          return;
        }
        noFaceFrames.current = 0;

        // Multiple faces
        if (detections.length > 1) {
          setFaceStatus("🚨 Multiple faces!");
          setFaceOk(false);
          triggerWarning("Multiple faces detected — impersonation suspected", "HIGH");
          return;
        }

        // Single face — check position
        const lm = detections[0].landmarks;
        const vw = video.videoWidth || 320;
        const vh = video.videoHeight || 240;
        const cx = vw / 2, cy = vh / 2;

        // Nose tip (landmark index 30)
        const nose = lm.positions[30];
        const hOff = (nose.x - cx) / vw;
        const vOff = (nose.y - cy) / vh;

        if (Math.abs(hOff) > 0.25) {
          const dir = hOff < 0 ? "LEFT" : "RIGHT";
          setFaceStatus(`⚠ Head turned ${dir}`);
          setFaceOk(false);
          triggerWarning(`Head turned ${dir} — looking away`, "MEDIUM");
          return;
        }
        if (vOff < -0.25) {
          setFaceStatus("⚠ Head tilted UP"); setFaceOk(false);
          triggerWarning("Head tilted UP — suspicious", "MEDIUM"); return;
        }
        if (vOff > 0.28) {
          setFaceStatus("⚠ Head tilted DOWN"); setFaceOk(false);
          triggerWarning("Head tilted DOWN — looking at notes?", "MEDIUM"); return;
        }

        // Eye gaze (inner eye corners: 39 left, 42 right)
        const leftInner = lm.positions[39];
        const rightInner = lm.positions[42];
        const gazeX = ((leftInner.x + rightInner.x) / 2 - cx) / vw;
        if (Math.abs(gazeX) > 0.20) {
          const dir = gazeX < 0 ? "LEFT" : "RIGHT";
          setFaceStatus(`👁 Eyes looking ${dir}`);
          setFaceOk(false);
          triggerWarning(`Eyes looking ${dir} — possible cheating`, "MEDIUM");
          return;
        }

        setFaceStatus("✅ Face OK");
        setFaceOk(true);
      } catch { /* ignore */ }
    }, 1200); // slightly longer interval = less CPU usage
  }, [modelsReady, triggerWarning]);

  useEffect(() => {
    if (cameraReady && modelsReady) startDetection();
    return () => clearInterval(detectRef.current);
  }, [cameraReady, modelsReady, startDetection]);

  // ── Submit exam ──
  const handleSubmit = async () => {
    if (submitted) return;
    setSubmitted(true);
    stopCamera();
    try {
      // Submit answers in parallel
      await Promise.all(
        questions
          .filter(q => answers[q.id])
          .map(q =>
            fetch("http://127.0.0.1:8000/post_answer", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                user_id: USER_ID, exam_id: +examId,
                question_id: q.id, selected_answer: answers[q.id]
              }),
            })
          )
      );
      const res = await fetch("http://127.0.0.1:8000/get_result", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user_id: USER_ID, exam_id: +examId }),
      });
      setResult(await res.json());
    } catch {
      setResult({ error: true, status: "ERROR" });
    }
  };

  const sc = s => s === "HIGH" ? "#ef4444" : s === "MEDIUM" ? "#f59e0b" : "#6b7280";

  // ── RESULT SCREEN ──
  if (submitted && result) {
    return (
      <div className="dashboard-container">
        <Sidebar />
        <div className="dashboard-main">
          <Navbar />
          <div style={{ display: "flex", justifyContent: "center", alignItems: "center", minHeight: "80vh", padding: 24 }}>
            <div style={{ background: "#fff", borderRadius: 20, padding: 40, maxWidth: 560, width: "100%", boxShadow: "0 8px 40px #0002", textAlign: "center" }}>
              <div style={{ fontSize: 64 }}>{result.status === "PASS" ? "🎉" : "😔"}</div>
              <h2 style={{ fontSize: 28, margin: "8px 0 4px" }}>{result.status === "PASS" ? "Congratulations!" : "Better luck next time"}</h2>
              <p style={{ color: "#9ca3af", marginBottom: 28 }}>{exam?.exam_name}</p>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 28 }}>
                {[
                  ["✅ Correct", result.correct, "#d1fae5", "#065f46"],
                  ["❌ Wrong", result.wrong, "#fee2e2", "#991b1b"],
                  ["📊 Score", `${Number(result.percentage || 0).toFixed(1)}%`, "#eff6ff", "#1d4ed8"],
                  ["🏆 Result", result.status, result.status === "PASS" ? "#d1fae5" : "#fee2e2", result.status === "PASS" ? "#065f46" : "#991b1b"],
                  ["🤖 AI Predict", result.ml_prediction, "#f5f3ff", "#6d28d9"],
                  ["⚡ Risk", result.risk_level, "#fef3c7", "#92400e"],
                  ["🔔 Warnings", warnCount.current, "#fef3c7", "#92400e"],
                  ["📝 Total Q", result.total, "#f9fafb", "#374151"],
                ].map(([l, v, bg, c]) => (
                  <div key={l} style={{ background: bg, borderRadius: 12, padding: "14px 16px", textAlign: "left" }}>
                    <p style={{ margin: 0, fontSize: 12, color: "#6b7280" }}>{l}</p>
                    <p style={{ margin: "4px 0 0", fontWeight: 800, fontSize: 20, color: c }}>{v}</p>
                  </div>
                ))}
              </div>
              <button onClick={() => navigate("/exams")} style={{ background: "#3b82f6", color: "#fff", border: "none", borderRadius: 10, padding: "12px 32px", fontWeight: 700, fontSize: 15, cursor: "pointer" }}>
                ← Back to Exams
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const q = questions[current];
  const opts = q ? [["A", q.option_a], ["B", q.option_b], ["C", q.option_c], ["D", q.option_d]] : [];

  return (
    <div className="dashboard-container" style={{ overflow: "hidden" }}>
      <Sidebar />
      <div className="dashboard-main" style={{ display: "flex", flexDirection: "column", height: "100vh", overflow: "hidden" }}>
        <Navbar />

        <div style={{ flex: 1, display: "grid", gridTemplateColumns: "1fr 300px", overflow: "hidden" }}>

          {/* ─── LEFT: EXAM QUESTIONS ─── */}
          <div style={{ overflowY: "auto", padding: "20px 24px", background: "#f8fafc" }}>

            {/* Header */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <div>
                <h2 style={{ margin: 0, fontSize: 20, fontWeight: 800 }}>{exam?.exam_name || "Loading..."}</h2>
                <p style={{ margin: 0, color: "#6b7280", fontSize: 13 }}>
                  {loadingQ ? "Loading questions..." : `Question ${current + 1} of ${questions.length}`}
                </p>
              </div>
              <div style={{ fontSize: 20, fontWeight: 800, background: timeLeft < 300 ? "#fee2e2" : "#eff6ff", color: timeLeft < 300 ? "#ef4444" : "#1d4ed8", padding: "8px 18px", borderRadius: 10 }}>
                ⏱ {fmt(timeLeft)}
              </div>
            </div>

            {/* Live alert banner */}
            {liveAlert && (
              <div style={{ background: liveAlert.severity === "HIGH" ? "#fee2e2" : "#fef3c7", border: `2px solid ${sc(liveAlert.severity)}`, borderRadius: 10, padding: "10px 16px", marginBottom: 14, display: "flex", gap: 10, alignItems: "center" }}>
                <span style={{ fontSize: 20 }}>🚨</span>
                <div>
                  <strong style={{ color: sc(liveAlert.severity), fontSize: 13 }}>{liveAlert.severity} WARNING</strong>
                  <p style={{ margin: 0, fontSize: 13 }}>{liveAlert.msg}</p>
                </div>
              </div>
            )}

            {/* Progress bar */}
            <div style={{ height: 5, background: "#e5e7eb", borderRadius: 99, marginBottom: 20 }}>
              <div style={{ height: "100%", background: "#3b82f6", borderRadius: 99, width: `${((current + 1) / Math.max(questions.length, 1)) * 100}%`, transition: "width 0.3s" }} />
            </div>

            {/* Loading state */}
            {loadingQ ? (
              <div style={{ textAlign: "center", padding: "60px 0", color: "#6b7280" }}>
                <div style={{ fontSize: 40, marginBottom: 12 }}>⏳</div>
                <p style={{ fontWeight: 600 }}>Loading questions from server...</p>
                <p style={{ fontSize: 13, color: "#9ca3af" }}>Make sure the backend is running on port 8000</p>
              </div>
            ) : questions.length === 0 ? (
              <div style={{ textAlign: "center", padding: "60px 0", color: "#6b7280", background: "#fff", borderRadius: 14, boxShadow: "0 2px 8px #0001" }}>
                <div style={{ fontSize: 40, marginBottom: 12 }}>📭</div>
                <p style={{ fontWeight: 700, fontSize: 16 }}>No questions found for this exam</p>
                <p style={{ fontSize: 13, color: "#9ca3af", marginBottom: 16 }}>Questions may not have been generated yet. Try creating the exam again with Ollama running.</p>
                <button onClick={() => navigate("/exams")} style={{ background: "#3b82f6", color: "#fff", border: "none", borderRadius: 8, padding: "10px 24px", fontWeight: 700, cursor: "pointer" }}>
                  ← Back to Exams
                </button>
              </div>
            ) : q ? (
              /* Question card */
              <div style={{ background: "#fff", borderRadius: 14, padding: 24, boxShadow: "0 2px 12px #0001", marginBottom: 16 }}>
                <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
                  <span style={{ background: q.mode === "Easy" ? "#d1fae5" : q.mode === "Hard" ? "#fee2e2" : "#fef3c7", color: q.mode === "Easy" ? "#065f46" : q.mode === "Hard" ? "#991b1b" : "#92400e", borderRadius: 20, padding: "2px 10px", fontSize: 11, fontWeight: 700 }}>{q.mode || "Medium"}</span>
                  <span style={{ color: "#9ca3af", fontSize: 12, alignSelf: "center" }}>Q{current + 1}</span>
                </div>
                <h3 style={{ fontSize: 17, marginBottom: 20, lineHeight: 1.5, color: "#1e293b" }}>{q.question_title}</h3>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                  {opts.map(([label, val]) => {
                    const sel = answers[q.id] === val;
                    return (
                      <button key={label} onClick={() => setAnswers(p => ({ ...p, [q.id]: val }))}
                        style={{ padding: "13px 16px", borderRadius: 10, textAlign: "left", border: sel ? "2px solid #3b82f6" : "2px solid #e5e7eb", background: sel ? "#eff6ff" : "#fff", cursor: "pointer", fontSize: 14, fontWeight: sel ? 700 : 400, color: "#1e293b", transition: "all 0.1s" }}>
                        <span style={{ color: sel ? "#3b82f6" : "#9ca3af", marginRight: 6, fontWeight: 800 }}>{label}.</span>{val}
                      </button>
                    );
                  })}
                </div>
              </div>
            ) : null}

            {/* Navigation */}
            {!loadingQ && questions.length > 0 && (
              <div style={{ display: "flex", gap: 10, marginBottom: 16 }}>
                <button onClick={() => setCurrent(c => Math.max(0, c - 1))} disabled={current === 0}
                  style={{ flex: 1, padding: "10px 0", borderRadius: 8, border: "1px solid #e5e7eb", background: "#fff", cursor: current === 0 ? "not-allowed" : "pointer", fontWeight: 600, opacity: current === 0 ? 0.4 : 1 }}>← Previous</button>
                {current < questions.length - 1
                  ? <button onClick={() => setCurrent(c => c + 1)} style={{ flex: 1, padding: "10px 0", borderRadius: 8, border: "none", background: "#3b82f6", color: "#fff", cursor: "pointer", fontWeight: 600 }}>Next →</button>
                  : <button onClick={handleSubmit} style={{ flex: 1, padding: "10px 0", borderRadius: 8, border: "none", background: "#10b981", color: "#fff", cursor: "pointer", fontWeight: 700 }}>✅ Submit</button>
                }
              </div>
            )}

            {/* Question palette */}
            {!loadingQ && questions.length > 0 && (
              <div style={{ background: "#fff", borderRadius: 12, padding: 14, boxShadow: "0 1px 6px #0001" }}>
                <p style={{ margin: "0 0 8px", fontWeight: 600, fontSize: 12, color: "#6b7280" }}>QUESTION PALETTE</p>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                  {questions.map((_, i) => (
                    <button key={i} onClick={() => setCurrent(i)}
                      style={{ width: 34, height: 34, borderRadius: 7, border: "2px solid", borderColor: i === current ? "#3b82f6" : answers[questions[i]?.id] ? "#10b981" : "#e5e7eb", background: i === current ? "#eff6ff" : answers[questions[i]?.id] ? "#d1fae5" : "#fff", cursor: "pointer", fontWeight: 700, fontSize: 12, color: i === current ? "#3b82f6" : answers[questions[i]?.id] ? "#065f46" : "#374151" }}>
                      {i + 1}
                    </button>
                  ))}
                </div>
                <div style={{ display: "flex", gap: 16, marginTop: 10, fontSize: 11, color: "#6b7280" }}>
                  <span>🔵 Current</span>
                  <span>🟢 Answered ({Object.keys(answers).length})</span>
                  <span>⬜ Remaining ({questions.length - Object.keys(answers).length})</span>
                </div>
              </div>
            )}
          </div>

          {/* ─── RIGHT: CAMERA PANEL ─── */}
          <div style={{ borderLeft: "1px solid #e5e7eb", background: "#fff", display: "flex", flexDirection: "column", overflowY: "auto" }}>

            <div style={{ padding: 14, borderBottom: "1px solid #f1f5f9" }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                <span style={{ fontWeight: 700, fontSize: 13 }}>📹 Proctoring</span>
                {cameraReady && <span style={{ color: "#10b981", fontWeight: 700, fontSize: 11 }}>● LIVE</span>}
              </div>

              {/* Clean video — no canvas overlay */}
              <div style={{ background: "#0f172a", borderRadius: 10, overflow: "hidden", aspectRatio: "4/3", position: "relative" }}>
                <video ref={videoRef} autoPlay muted playsInline
                  style={{ width: "100%", height: "100%", objectFit: "cover", display: cameraReady ? "block" : "none", transform: "scaleX(-1)" }} />
                {!cameraReady && (
                  <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100%", color: "#475569", gap: 6 }}>
                    <span style={{ fontSize: 36 }}>📷</span>
                    <span style={{ fontSize: 11 }}>{loadingModels ? "Loading AI models..." : "Camera off"}</span>
                  </div>
                )}
              </div>

              {/* Face status */}
              <div style={{ marginTop: 8, padding: "8px 10px", borderRadius: 8, background: faceOk ? "#f0fdf4" : "#fef2f2", border: `1px solid ${faceOk ? "#bbf7d0" : "#fecaca"}`, fontSize: 12, fontWeight: 600, color: faceOk ? "#166534" : "#991b1b" }}>
                {faceStatus}
              </div>

              {!cameraReady ? (
                <button onClick={startCamera} disabled={!modelsReady}
                  style={{ width: "100%", marginTop: 8, padding: "9px 0", borderRadius: 8, border: "none", background: modelsReady ? "#3b82f6" : "#cbd5e1", color: "#fff", cursor: modelsReady ? "pointer" : "not-allowed", fontWeight: 700, fontSize: 13 }}>
                  {modelsReady ? "▶ Start Camera" : "⏳ Loading models..."}
                </button>
              ) : (
                <button onClick={stopCamera}
                  style={{ width: "100%", marginTop: 8, padding: "9px 0", borderRadius: 8, border: "none", background: "#ef4444", color: "#fff", cursor: "pointer", fontWeight: 700, fontSize: 13 }}>
                  ⏹ Stop Camera
                </button>
              )}
            </div>

            {/* Warning log */}
            <div style={{ flex: 1, padding: 14, overflowY: "auto" }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                <span style={{ fontWeight: 700, fontSize: 13 }}>⚠ Warnings</span>
                <span style={{ background: warnCount.current > 0 ? "#fee2e2" : "#f1f5f9", color: warnCount.current > 0 ? "#ef4444" : "#6b7280", borderRadius: 20, padding: "1px 8px", fontSize: 12, fontWeight: 700 }}>
                  {warnCount.current}
                </span>
              </div>
              {warnings.length === 0 ? (
                <div style={{ textAlign: "center", color: "#9ca3af", padding: "16px 0" }}>
                  <div style={{ fontSize: 24 }}>✅</div>
                  <p style={{ fontSize: 12, margin: "4px 0" }}>No warnings</p>
                </div>
              ) : warnings.map(w => (
                <div key={w.id} style={{ marginBottom: 8, padding: "8px 10px", borderRadius: 8, background: w.severity === "HIGH" ? "#fee2e2" : "#fef3c7", borderLeft: `3px solid ${sc(w.severity)}` }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 2 }}>
                    <strong style={{ fontSize: 11, color: sc(w.severity) }}>{w.severity}</strong>
                    <span style={{ fontSize: 10, color: "#9ca3af" }}>{w.time}</span>
                  </div>
                  <p style={{ margin: 0, fontSize: 11, color: "#374151" }}>{w.msg}</p>
                </div>
              ))}
            </div>

            {/* Submit */}
            <div style={{ padding: 14, borderTop: "1px solid #f1f5f9" }}>
              <button onClick={handleSubmit}
                style={{ width: "100%", padding: "11px 0", borderRadius: 10, border: "none", background: "linear-gradient(135deg,#10b981,#059669)", color: "#fff", fontWeight: 800, fontSize: 14, cursor: "pointer" }}>
                ✅ Submit Exam
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Examination;
