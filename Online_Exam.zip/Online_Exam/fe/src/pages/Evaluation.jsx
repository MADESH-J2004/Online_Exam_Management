import { useEffect, useState } from "react";
import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";

function Evaluation() {
  const [summary, setSummary] = useState(null);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([
      fetch("http://127.0.0.1:8000/results/summary").then(r => r.json()),
      fetch("http://127.0.0.1:8000/results").then(r => r.json()),
    ])
      .then(([sum, res]) => {
        setSummary(sum);
        setResults(Array.isArray(res) ? res : []);
        setLoading(false);
      })
      .catch(() => {
        setError("Failed to load evaluation data. Ensure the backend is running.");
        setLoading(false);
      });
  }, []);

  const card = (label, value, color, bg, icon) => (
    <div key={label} style={{ background: bg, borderRadius: 14, padding: "22px 24px", flex: 1, minWidth: 140 }}>
      <p style={{ margin: 0, fontSize: 13, color: "#6b7280" }}>{icon} {label}</p>
      <p style={{ margin: "6px 0 0", fontSize: 30, fontWeight: 800, color }}>{value}</p>
    </div>
  );

  return (
    <div className="layout" style={{ display: "flex", minHeight: "100vh" }}>
      <Sidebar />
      <div className="main" style={{ flex: 1, display: "flex", flexDirection: "column" }}>
        <Navbar />
        <div style={{ padding: 28, background: "#f5f7fb", flex: 1 }}>
          <h2 style={{ margin: "0 0 6px", fontWeight: 800, fontSize: 24, color: "#1e293b" }}>
            📊 Auto Evaluation
          </h2>
          <p style={{ margin: "0 0 24px", color: "#6b7280", fontSize: 14 }}>
            Overview of all student exam results and performance metrics.
          </p>

          {loading ? (
            <div style={{ textAlign: "center", padding: "60px 0", color: "#6b7280" }}>
              <div style={{ fontSize: 36 }}>⏳</div>
              <p style={{ fontWeight: 600, marginTop: 10 }}>Loading evaluation data…</p>
            </div>
          ) : error ? (
            <div style={{ padding: "18px 20px", background: "#fef3c7", borderRadius: 12, color: "#92400e", fontWeight: 600 }}>
              ⚠ {error}
            </div>
          ) : summary ? (
            <>
              {/* Summary Cards */}
              <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 28 }}>
                {card("Total Results",  summary.total_results,             "#1d4ed8", "#eff6ff",  "📋")}
                {card("Avg Score",      `${summary.avg_percentage}%`,      "#059669", "#f0fdf4",  "📈")}
                {card("Pass Rate",      `${summary.pass_rate}%`,           "#7c3aed", "#f5f3ff",  "✅")}
                {card("Top Score",      `${summary.top_score}%`,           "#b45309", "#fefce8",  "🏆")}
                {card("Passed",         summary.passed,                    "#065f46", "#d1fae5",  "🟢")}
                {card("Failed",         summary.failed,                    "#991b1b", "#fee2e2",  "🔴")}
              </div>

              {/* Per-Subject breakdown */}
              {summary.subjects && summary.subjects.length > 0 && (
                <div style={{ background: "#fff", borderRadius: 16, padding: 24, boxShadow: "0 2px 12px #0001", marginBottom: 28 }}>
                  <h3 style={{ margin: "0 0 16px", fontSize: 16, fontWeight: 700, color: "#1e293b" }}>📚 Subject-wise Performance</h3>
                  <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
                    <thead>
                      <tr style={{ background: "#f8fafc" }}>
                        {["Exam", "Subject", "Attempts", "Avg Score"].map(h => (
                          <th key={h} style={{ padding: "10px 14px", textAlign: "left", fontWeight: 700, color: "#374151", borderBottom: "1px solid #e5e7eb" }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {summary.subjects.map((s, i) => (
                        <tr key={i} style={{ borderBottom: "1px solid #f1f5f9" }}>
                          <td style={{ padding: "10px 14px", fontWeight: 600, color: "#1e293b" }}>{s.exam_name || "—"}</td>
                          <td style={{ padding: "10px 14px", color: "#6b7280" }}>{s.subject_name || "—"}</td>
                          <td style={{ padding: "10px 14px" }}>{s.attempts}</td>
                          <td style={{ padding: "10px 14px" }}>
                            <span style={{
                              background: s.avg_pct >= 60 ? "#d1fae5" : "#fee2e2",
                              color: s.avg_pct >= 60 ? "#065f46" : "#991b1b",
                              padding: "2px 10px", borderRadius: 20, fontWeight: 700, fontSize: 13
                            }}>
                              {Number(s.avg_pct || 0).toFixed(1)}%
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* All Results Table */}
              <div style={{ background: "#fff", borderRadius: 16, padding: 24, boxShadow: "0 2px 12px #0001" }}>
                <h3 style={{ margin: "0 0 16px", fontSize: 16, fontWeight: 700, color: "#1e293b" }}>🗂 All Student Results</h3>
                {results.length === 0 ? (
                  <p style={{ color: "#9ca3af", textAlign: "center", padding: "30px 0" }}>No results recorded yet.</p>
                ) : (
                  <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
                    <thead>
                      <tr style={{ background: "#f8fafc" }}>
                        {["Student", "Exam", "Subject", "Score", "Status", "Date"].map(h => (
                          <th key={h} style={{ padding: "10px 14px", textAlign: "left", fontWeight: 700, color: "#374151", borderBottom: "1px solid #e5e7eb" }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {results.map(r => (
                        <tr key={r.result_id} style={{ borderBottom: "1px solid #f1f5f9" }}>
                          <td style={{ padding: "10px 14px", fontWeight: 600 }}>{r.user_name || `User ${r.user_id}`}</td>
                          <td style={{ padding: "10px 14px" }}>{r.exam_name || "—"}</td>
                          <td style={{ padding: "10px 14px", color: "#6b7280" }}>{r.subject_name || "—"}</td>
                          <td style={{ padding: "10px 14px" }}>{r.correct_answers}/{r.total_quiz} ({r.percentage}%)</td>
                          <td style={{ padding: "10px 14px" }}>
                            <span style={{
                              background: r.result_status === "PASS" ? "#d1fae5" : "#fee2e2",
                              color: r.result_status === "PASS" ? "#065f46" : "#991b1b",
                              padding: "2px 10px", borderRadius: 20, fontWeight: 700, fontSize: 12
                            }}>
                              {r.result_status}
                            </span>
                          </td>
                          <td style={{ padding: "10px 14px", color: "#9ca3af", fontSize: 13 }}>
                            {r.result_date ? new Date(r.result_date).toLocaleDateString() : "—"}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </>
          ) : null}
        </div>
      </div>
    </div>
  );
}

export default Evaluation;
