import { useEffect, useState, useMemo } from "react";
import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";
import "./QuestionBank.css";

const EMPTY = {
  exam_id: "",
  question_title: "",
  option_a: "",
  option_b: "",
  option_c: "",
  option_d: "",
  correct_answer: "",
  mode: "Easy",
};

function QuestionBank() {
  const [questions, setQuestions] = useState([]);
  const [exams, setExams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // Modal state
  const [showModal, setShowModal] = useState(false);
  const [editId, setEditId] = useState(null); // null = add, number = edit
  const [form, setForm] = useState(EMPTY);
  const [errors, setErrors] = useState({});

  // Search & filter
  const [search, setSearch] = useState("");
  const [filterMode, setFilterMode] = useState("All");
  const [filterExam, setFilterExam] = useState("All");

  // Delete confirm
  const [deleteId, setDeleteId] = useState(null);

  // ── Fetch data ──
  const fetchQuestions = () => {
    fetch("http://127.0.0.1:8000/get_quiz")
      .then(r => r.json())
      .then(data => { setQuestions(data); setLoading(false); })
      .catch(() => setLoading(false));
  };

  useEffect(() => {
    fetchQuestions();
    fetch("http://127.0.0.1:8000/get_exam")
      .then(r => r.json())
      .then(setExams)
      .catch(() => {});
  }, []);

  // ── Filter & Search ──
  const filtered = useMemo(() => {
    return questions.filter(q => {
      const matchSearch = !search || q.question_title?.toLowerCase().includes(search.toLowerCase());
      const matchMode = filterMode === "All" || q.mode === filterMode;
      const matchExam = filterExam === "All" || String(q.exam_id) === String(filterExam);
      return matchSearch && matchMode && matchExam;
    });
  }, [questions, search, filterMode, filterExam]);

  // ── Validate ──
  const validate = () => {
    const e = {};
    if (!form.exam_id)        e.exam_id = "Select an exam";
    if (!form.question_title.trim()) e.question_title = "Question is required";
    if (!form.option_a.trim()) e.option_a = "Required";
    if (!form.option_b.trim()) e.option_b = "Required";
    if (!form.option_c.trim()) e.option_c = "Required";
    if (!form.option_d.trim()) e.option_d = "Required";
    if (!form.correct_answer)  e.correct_answer = "Select correct answer";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  // ── Save (Add or Edit) ──
  const handleSave = async () => {
    if (!validate()) return;
    setSaving(true);
    try {
      const url = editId
        ? `http://127.0.0.1:8000/update_question/${editId}`
        : "http://127.0.0.1:8000/add_question";
      const method = editId ? "PUT" : "POST";
      await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, exam_id: +form.exam_id }),
      });
      setShowModal(false);
      setForm(EMPTY);
      setEditId(null);
      setErrors({});
      fetchQuestions();
    } catch {
      alert("Save failed — is the backend running?");
    }
    setSaving(false);
  };

  // ── Delete ──
  const handleDelete = async (id) => {
    try {
      await fetch(`http://127.0.0.1:8000/delete_question/${id}`, { method: "DELETE" });
      setDeleteId(null);
      fetchQuestions();
    } catch { alert("Delete failed"); }
  };

  // ── Open modals ──
  const openAdd = () => {
    setForm(EMPTY); setEditId(null); setErrors({}); setShowModal(true);
  };
  const openEdit = (q) => {
    setForm({ exam_id: q.exam_id, question_title: q.question_title, option_a: q.option_a, option_b: q.option_b, option_c: q.option_c, option_d: q.option_d, correct_answer: q.correct_answer, mode: q.mode });
    setEditId(q.id); setErrors({}); setShowModal(true);
  };

  const inp = { width: "100%", padding: "9px 12px", borderRadius: 8, border: "1px solid #e5e7eb", fontSize: 14, boxSizing: "border-box", outline: "none" };
  const lbl = { fontSize: 13, fontWeight: 600, color: "#374151", display: "block", marginBottom: 4, marginTop: 12 };
  const err = { fontSize: 11, color: "#ef4444", marginTop: 2 };

  const modeStyle = (mode) => {
    if (mode === "Easy")   return { background: "#d1fae5", color: "#065f46" };
    if (mode === "Hard")   return { background: "#fee2e2", color: "#991b1b" };
    return                        { background: "#fef3c7", color: "#92400e" };
  };

  const examName = (id) => exams.find(e => String(e.id) === String(id))?.exam_name || `Exam ${id}`;

  return (
    <div className="dashboard-container">
      <Sidebar />
      <div className="dashboard-main">
        <Navbar />
        <div className="dashboard-content">

          {/* Header */}
          <div className="qb-header">
            <div>
              <h1>Question Bank</h1>
              <p>Manage exam questions and MCQs</p>
            </div>
            <div className="qb-buttons">
              <button className="upload-btn">⬆ Bulk Upload</button>
              <button className="add-btn" onClick={openAdd}>+ Add Question</button>
            </div>
          </div>

          {/* Search & Filter */}
          <div className="search-bar">
            <input
              type="text"
              placeholder="Search questions..."
              className="search-input"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
            <select className="filter" value={filterMode} onChange={e => setFilterMode(e.target.value)}>
              <option value="All">All Difficulty</option>
              <option>Easy</option>
              <option>Medium</option>
              <option>Hard</option>
            </select>
            <select className="filter" value={filterExam} onChange={e => setFilterExam(e.target.value)}>
              <option value="All">All Exams</option>
              {exams.map(ex => <option key={ex.id} value={ex.id}>{ex.exam_name}</option>)}
            </select>
          </div>

          {/* Stats */}
          <div style={{ display: "flex", gap: 10, marginBottom: 18, flexWrap: "wrap" }}>
            {[
              { label: "Total", value: questions.length, color: "#3b82f6" },
              { label: "Easy", value: questions.filter(q => q.mode === "Easy").length, color: "#10b981" },
              { label: "Medium", value: questions.filter(q => q.mode === "Medium").length, color: "#f59e0b" },
              { label: "Hard", value: questions.filter(q => q.mode === "Hard").length, color: "#ef4444" },
            ].map(s => (
              <div key={s.label} style={{ background: "#fff", borderRadius: 10, padding: "10px 18px", boxShadow: "0 1px 4px #0001", display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ fontWeight: 800, fontSize: 18, color: s.color }}>{s.value}</span>
                <span style={{ fontSize: 13, color: "#6b7280" }}>{s.label}</span>
              </div>
            ))}
            {filtered.length !== questions.length && (
              <div style={{ background: "#eff6ff", borderRadius: 10, padding: "10px 18px", display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ fontWeight: 800, fontSize: 18, color: "#3b82f6" }}>{filtered.length}</span>
                <span style={{ fontSize: 13, color: "#6b7280" }}>Showing</span>
              </div>
            )}
          </div>

          {/* Question List */}
          {loading ? (
            <div style={{ textAlign: "center", padding: "60px 0", color: "#9ca3af" }}>⏳ Loading questions...</div>
          ) : filtered.length === 0 ? (
            <div style={{ textAlign: "center", padding: "60px 0", color: "#9ca3af", background: "#fff", borderRadius: 12 }}>
              <div style={{ fontSize: 40 }}>📭</div>
              <p style={{ fontWeight: 600, marginTop: 8 }}>{search || filterMode !== "All" || filterExam !== "All" ? "No questions match your search" : "No questions yet — click + Add Question"}</p>
            </div>
          ) : (
            filtered.map((q) => (
              <div className="question-card" key={q.id}>
                <div className="question-top">
                  <div className="tags">
                    <span style={{ ...modeStyle(q.mode), padding: "3px 12px", borderRadius: 20, fontSize: 12, fontWeight: 700 }}>{q.mode}</span>
                    <span style={{ background: "#f1f5f9", color: "#475569", padding: "3px 10px", borderRadius: 20, fontSize: 12 }}>
                      {examName(q.exam_id)}
                    </span>
                  </div>
                  <div style={{ display: "flex", gap: 6 }}>
                    <button onClick={() => openEdit(q)} title="Edit" style={{ background: "#fff7ed", border: "1px solid #fed7aa", borderRadius: 7, padding: "5px 10px", cursor: "pointer", fontSize: 14 }}>✏️</button>
                    <button onClick={() => setDeleteId(q.id)} title="Delete" style={{ background: "#fff1f2", border: "1px solid #fecdd3", borderRadius: 7, padding: "5px 10px", cursor: "pointer", fontSize: 14 }}>🗑️</button>
                  </div>
                </div>

                <h3 className="question-text">{q.question_title}</h3>

                <div className="options">
                  {[["A", q.option_a], ["B", q.option_b], ["C", q.option_c], ["D", q.option_d]].map(([label, val]) => {
                    const isCorrect = val === q.correct_answer;
                    return (
                      <div key={label} className={`option ${isCorrect ? "correct" : ""}`} style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        {isCorrect && <span style={{ fontSize: 13 }}>✅</span>}
                        <span style={{ fontWeight: 700, color: "#9ca3af" }}>{label}.</span> {val}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* ── ADD / EDIT MODAL ── */}
      {showModal && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
          <div style={{ background: "#fff", borderRadius: 16, padding: 28, width: 560, maxWidth: "100%", maxHeight: "90vh", overflowY: "auto", boxShadow: "0 20px 60px rgba(0,0,0,0.2)" }}>

            {/* Modal header */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
              <h2 style={{ margin: 0, fontSize: 20 }}>{editId ? "✏️ Edit Question" : "➕ Add New Question"}</h2>
              <button onClick={() => { setShowModal(false); setErrors({}); }} style={{ background: "none", border: "none", fontSize: 22, cursor: "pointer", color: "#6b7280" }}>✕</button>
            </div>
            <p style={{ color: "#9ca3af", fontSize: 13, marginBottom: 16 }}>Fill in all fields and choose the correct answer</p>

            {/* Exam selector */}
            <label style={lbl}>Exam *</label>
            <select value={form.exam_id} onChange={e => setForm(p => ({ ...p, exam_id: e.target.value }))}
              style={{ ...inp, borderColor: errors.exam_id ? "#ef4444" : "#e5e7eb" }}>
              <option value="">-- Select Exam --</option>
              {exams.map(ex => <option key={ex.id} value={ex.id}>{ex.exam_name}</option>)}
            </select>
            {errors.exam_id && <p style={err}>{errors.exam_id}</p>}

            {/* Difficulty */}
            <label style={lbl}>Difficulty *</label>
            <select value={form.mode} onChange={e => setForm(p => ({ ...p, mode: e.target.value }))} style={inp}>
              <option>Easy</option>
              <option>Medium</option>
              <option>Hard</option>
            </select>

            {/* Question */}
            <label style={lbl}>Question *</label>
            <textarea value={form.question_title} onChange={e => setForm(p => ({ ...p, question_title: e.target.value }))}
              rows={3} placeholder="Enter the question here..."
              style={{ ...inp, resize: "vertical", borderColor: errors.question_title ? "#ef4444" : "#e5e7eb" }} />
            {errors.question_title && <p style={err}>{errors.question_title}</p>}

            {/* Options */}
            <div style={{ background: "#f8fafc", borderRadius: 10, padding: 14, marginTop: 12 }}>
              <p style={{ margin: "0 0 10px", fontWeight: 700, fontSize: 13, color: "#374151" }}>Answer Options *</p>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                {["a", "b", "c", "d"].map(key => {
                  const label = key.toUpperCase();
                  const field = `option_${key}`;
                  const isCorrect = form.correct_answer === form[field] && form[field];
                  return (
                    <div key={key}>
                      <label style={{ ...lbl, marginTop: 0, display: "flex", alignItems: "center", gap: 6 }}>
                        <span style={{ background: isCorrect ? "#10b981" : "#e5e7eb", color: isCorrect ? "#fff" : "#374151", borderRadius: "50%", width: 22, height: 22, display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 800, flexShrink: 0 }}>{label}</span>
                        Option {label} *
                      </label>
                      <input
                        value={form[field]}
                        onChange={e => setForm(p => ({ ...p, [field]: e.target.value }))}
                        placeholder={`Option ${label}`}
                        style={{ ...inp, borderColor: errors[field] ? "#ef4444" : isCorrect ? "#10b981" : "#e5e7eb", background: isCorrect ? "#f0fdf4" : "#fff" }}
                      />
                      {errors[field] && <p style={err}>{errors[field]}</p>}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Correct Answer */}
            <label style={lbl}>Correct Answer *</label>
            <select value={form.correct_answer} onChange={e => setForm(p => ({ ...p, correct_answer: e.target.value }))}
              style={{ ...inp, borderColor: errors.correct_answer ? "#ef4444" : "#e5e7eb" }}>
              <option value="">-- Select correct option --</option>
              {form.option_a && <option value={form.option_a}>A: {form.option_a}</option>}
              {form.option_b && <option value={form.option_b}>B: {form.option_b}</option>}
              {form.option_c && <option value={form.option_c}>C: {form.option_c}</option>}
              {form.option_d && <option value={form.option_d}>D: {form.option_d}</option>}
            </select>
            {errors.correct_answer && <p style={err}>{errors.correct_answer}</p>}

            {/* Live preview of correct answer */}
            {form.correct_answer && (
              <div style={{ marginTop: 10, padding: "10px 14px", background: "#d1fae5", borderRadius: 8, fontSize: 13, color: "#065f46", fontWeight: 600 }}>
                ✅ Correct answer: {form.correct_answer}
              </div>
            )}

            {/* Buttons */}
            <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
              <button onClick={() => { setShowModal(false); setErrors({}); }} disabled={saving}
                style={{ flex: 1, padding: "11px 0", borderRadius: 8, border: "1px solid #e5e7eb", background: "#fff", cursor: "pointer", fontWeight: 600 }}>
                Cancel
              </button>
              <button onClick={handleSave} disabled={saving}
                style={{ flex: 2, padding: "11px 0", borderRadius: 8, border: "none", background: saving ? "#93c5fd" : "#3b82f6", color: "#fff", cursor: saving ? "not-allowed" : "pointer", fontWeight: 700, fontSize: 15 }}>
                {saving ? "⏳ Saving..." : editId ? "💾 Save Changes" : "✅ Add Question"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── DELETE CONFIRM ── */}
      {deleteId && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <div style={{ background: "#fff", borderRadius: 14, padding: 28, width: 360, textAlign: "center", boxShadow: "0 10px 40px rgba(0,0,0,0.2)" }}>
            <div style={{ fontSize: 48 }}>🗑️</div>
            <h3 style={{ margin: "12px 0 6px" }}>Delete Question?</h3>
            <p style={{ color: "#6b7280", fontSize: 14, marginBottom: 20 }}>This action cannot be undone.</p>
            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={() => setDeleteId(null)} style={{ flex: 1, padding: "10px 0", borderRadius: 8, border: "1px solid #e5e7eb", background: "#fff", cursor: "pointer", fontWeight: 600 }}>Cancel</button>
              <button onClick={() => handleDelete(deleteId)} style={{ flex: 1, padding: "10px 0", borderRadius: 8, border: "none", background: "#ef4444", color: "#fff", cursor: "pointer", fontWeight: 700 }}>Delete</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default QuestionBank;
