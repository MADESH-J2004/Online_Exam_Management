import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";
import "./ExamManagement.css";

// ─── Modal defined OUTSIDE component so it never remounts on re-render ───────
function Modal({ title, children, onClose, onSave, saveLabel, saving }) {
  return (
    <div
      style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center" }}
      onClick={(e) => { if (e.target === e.currentTarget && !saving) onClose(); }}
    >
      <div style={{ background: "#fff", borderRadius: 16, padding: 28, width: 540, maxWidth: "95vw", maxHeight: "90vh", overflowY: "auto", boxShadow: "0 20px 60px rgba(0,0,0,0.25)" }}
        onClick={e => e.stopPropagation()}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <h2 style={{ margin: 0, fontSize: 20 }}>{title}</h2>
          <button onClick={onClose} disabled={saving} style={{ background: "none", border: "none", fontSize: 22, cursor: saving ? "not-allowed" : "pointer", color: "#6b7280" }}>✕</button>
        </div>
        {children}
        <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
          <button onClick={onClose} disabled={saving}
            style={{ flex: 1, padding: "11px 0", borderRadius: 8, border: "1px solid #e5e7eb", background: "#fff", cursor: saving ? "not-allowed" : "pointer", fontWeight: 600 }}>
            Cancel
          </button>
          <button onClick={onSave} disabled={saving}
            style={{ flex: 2, padding: "11px 0", borderRadius: 8, border: "none", background: saving ? "#93c5fd" : "#3b82f6", color: "#fff", cursor: saving ? "not-allowed" : "pointer", fontWeight: 700 }}>
            {saving ? "⏳ Please wait..." : saveLabel}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────

function ExamManagement() {
  const navigate = useNavigate();
  const [exams, setExams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [showEdit, setShowEdit] = useState(false);
  const [editExam, setEditExam] = useState(null);
  const [generating, setGenerating] = useState(false);
  const [genStatus, setGenStatus] = useState("");
  const [ollamaStatus, setOllamaStatus] = useState(null);

  const emptyForm = {
    exam_name: "", subject_name: "", duration: 60,
    total_marks: 100, start_date: "", end_date: "",
    num_questions: 5, difficulty: "Mixed"
  };
  const [form, setForm] = useState(emptyForm);

  const fetchExams = () => {
    setLoading(true);
    fetch("http://127.0.0.1:8000/get_exam")
      .then(r => r.json())
      .then(data => { setExams(data); setLoading(false); })
      .catch(() => setLoading(false));
  };

  useEffect(() => {
    fetchExams();
    fetch("http://127.0.0.1:8000/ollama_status")
      .then(r => r.json())
      .then(setOllamaStatus)
      .catch(() => setOllamaStatus({ status: "offline" }));
  }, []);

  // ── Stable change handler ──
  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const handleCreate = async () => {
    if (!form.exam_name.trim() || !form.subject_name.trim() || !form.start_date || !form.end_date) {
      alert("Please fill all required fields (Exam Name, Subject, Start Date, End Date)");
      return;
    }
    setGenerating(true);
    setGenStatus(`🤖 Asking Ollama to generate ${form.num_questions} questions about ${form.subject_name}...`);
    try {
      const res = await fetch("http://127.0.0.1:8000/create_exam", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          num_questions: +form.num_questions,
          duration: +form.duration,
          total_marks: +form.total_marks
        }),
      });
      const data = await res.json();
      setGenStatus(`✅ Done! ${data.questions_generated} questions generated.`);
      setTimeout(() => {
        setShowCreate(false);
        setGenerating(false);
        setGenStatus("");
        setForm(emptyForm);
        fetchExams();
      }, 1800);
    } catch {
      setGenStatus("❌ Error — is the backend running on port 8000?");
      setGenerating(false);
    }
  };

  const openEdit = (exam) => {
    setEditExam({ ...exam });
    setShowEdit(true);
  };

  const handleEditSave = async () => {
    try {
      await fetch(`http://127.0.0.1:8000/update_exam/${editExam.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editExam),
      });
      setShowEdit(false);
      fetchExams();
    } catch {
      alert("Save failed — check backend");
    }
  };

  const inp = {
    width: "100%", padding: "9px 12px", borderRadius: 8,
    border: "1px solid #e5e7eb", fontSize: 14,
    boxSizing: "border-box", marginTop: 4, outline: "none"
  };
  const lbl = {
    fontSize: 13, fontWeight: 600, color: "#374151",
    display: "block", marginTop: 12
  };

  return (
    <div className="dashboard-container">
      <Sidebar />
      <div className="dashboard-main">
        <Navbar />
        <div className="dashboard-content">

          <div className="exam-header">
            <div>
              <h1>Exam Management</h1>
              <p>Create and manage examinations — AI-powered question generation</p>
            </div>
            <button className="create-btn" onClick={() => { setForm(emptyForm); setGenStatus(""); setShowCreate(true); }}>
              + Create Exam
            </button>
          </div>

          {/* Ollama status */}
          {ollamaStatus && (
            <div style={{ marginBottom: 16 }}>
              <span style={{
                display: "inline-flex", alignItems: "center", gap: 6,
                background: ollamaStatus.status === "online" ? "#d1fae5" : "#fee2e2",
                color: ollamaStatus.status === "online" ? "#065f46" : "#991b1b",
                padding: "5px 14px", borderRadius: 20, fontSize: 13, fontWeight: 600
              }}>
                {ollamaStatus.status === "online" ? "🟢" : "🔴"} Ollama{" "}
                {ollamaStatus.status === "online"
                  ? `Online — ${ollamaStatus.models?.join(", ")}`
                  : "Offline"}
              </span>
            </div>
          )}

          {/* Exam grid */}
          {loading ? <p>Loading exams...</p> : (
            <div className="exam-grid">
              {exams.length > 0 ? exams.map(exam => (
                <div className="exam-card" key={exam.id}>
                  <div className="exam-top">
                    <h3>{exam.exam_name}</h3>
                    <span className="badge active">Active</span>
                  </div>
                  <p className="info">📄 {exam.subject_name}</p>
                  <p className="info">⏱ {exam.duration} minutes</p>
                  <p className="info">🏆 {exam.total_marks} marks</p>
                  <p className="info">📅 {exam.start_date}</p>
                  <hr />
                  <div className="exam-actions">
                    <button className="view-btn" onClick={() => navigate(`/exams/${exam.id}`)}>👁 View</button>
                    <button className="edit-btn" onClick={() => openEdit(exam)}>✏️ Edit</button>
                  </div>
                </div>
              )) : (
                <div style={{ textAlign: "center", padding: "60px 0", color: "#9ca3af" }}>
                  <p style={{ fontSize: 40 }}>📝</p>
                  <p style={{ fontWeight: 600 }}>No exams found. Create your first exam!</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* ── CREATE MODAL ── */}
      {showCreate && (
        <Modal
          title="Create New Exam"
          onClose={() => !generating && setShowCreate(false)}
          onSave={handleCreate}
          saveLabel="🚀 Create + Generate Questions"
          saving={generating}
        >
          <p style={{ color: "#6b7280", fontSize: 13, margin: "0 0 10px" }}>
            Questions will be auto-generated by Ollama AI
          </p>
          <div style={{ background: "#eff6ff", borderRadius: 8, padding: "8px 14px", marginBottom: 6, fontSize: 13, color: "#1e40af" }}>
            🤖 Ollama generates MCQs based on the subject &amp; difficulty you choose.
          </div>

          <label style={lbl}>Exam Name *</label>
          <input
            name="exam_name"
            value={form.exam_name}
            onChange={handleChange}
            style={inp}
            placeholder="e.g. Mathematics Final Exam"
            disabled={generating}
            autoComplete="off"
          />

          <label style={lbl}>Subject *</label>
          <input
            name="subject_name"
            value={form.subject_name}
            onChange={handleChange}
            style={inp}
            placeholder="e.g. Mathematics, Physics"
            disabled={generating}
            autoComplete="off"
          />

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={lbl}>Duration (min)</label>
              <input type="number" name="duration" value={form.duration} onChange={handleChange} style={inp} disabled={generating} />
            </div>
            <div>
              <label style={lbl}>Total Marks</label>
              <input type="number" name="total_marks" value={form.total_marks} onChange={handleChange} style={inp} disabled={generating} />
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={lbl}>Start Date *</label>
              <input type="date" name="start_date" value={form.start_date} onChange={handleChange} style={inp} disabled={generating} />
            </div>
            <div>
              <label style={lbl}>End Date *</label>
              <input type="date" name="end_date" value={form.end_date} onChange={handleChange} style={inp} disabled={generating} />
            </div>
          </div>

          <div style={{ background: "#f0fdf4", border: "1px solid #86efac", borderRadius: 10, padding: 14, marginTop: 14 }}>
            <p style={{ margin: "0 0 8px", fontWeight: 700, color: "#166534", fontSize: 13 }}>🤖 AI Question Settings</p>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <div>
                <label style={{ ...lbl, color: "#166534" }}># Questions</label>
                <select name="num_questions" value={form.num_questions} onChange={handleChange} style={inp} disabled={generating}>
                  {[3, 5, 7, 10, 15, 20].map(n => <option key={n} value={n}>{n}</option>)}
                </select>
              </div>
              <div>
                <label style={{ ...lbl, color: "#166534" }}>Difficulty</label>
                <select name="difficulty" value={form.difficulty} onChange={handleChange} style={inp} disabled={generating}>
                  {["Mixed", "Easy", "Medium", "Hard"].map(d => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
            </div>
          </div>

          {genStatus && (
            <div style={{ marginTop: 12, padding: "10px 14px", background: "#f0f9ff", borderRadius: 8, fontSize: 13, color: "#0369a1", border: "1px solid #bae6fd" }}>
              {genStatus}
            </div>
          )}
        </Modal>
      )}

      {/* ── EDIT MODAL ── */}
      {showEdit && editExam && (
        <Modal
          title="✏️ Edit Exam"
          onClose={() => setShowEdit(false)}
          onSave={handleEditSave}
          saveLabel="💾 Save Changes"
          saving={false}
        >
          <label style={lbl}>Exam Name</label>
          <input
            value={editExam.exam_name || ""}
            onChange={e => setEditExam(p => ({ ...p, exam_name: e.target.value }))}
            style={inp}
            autoComplete="off"
          />

          <label style={lbl}>Subject</label>
          <input
            value={editExam.subject_name || ""}
            onChange={e => setEditExam(p => ({ ...p, subject_name: e.target.value }))}
            style={inp}
            autoComplete="off"
          />

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={lbl}>Duration (min)</label>
              <input type="number" value={editExam.duration || 0}
                onChange={e => setEditExam(p => ({ ...p, duration: +e.target.value }))} style={inp} />
            </div>
            <div>
              <label style={lbl}>Total Marks</label>
              <input type="number" value={editExam.total_marks || 0}
                onChange={e => setEditExam(p => ({ ...p, total_marks: +e.target.value }))} style={inp} />
            </div>
          </div>

          <label style={lbl}>Start Date</label>
          <input type="date" value={editExam.start_date || ""}
            onChange={e => setEditExam(p => ({ ...p, start_date: e.target.value }))} style={inp} />
        </Modal>
      )}
    </div>
  );
}

export default ExamManagement;
