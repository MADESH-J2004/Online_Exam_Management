import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";

function ExamView() {
  const { examId } = useParams();
  const navigate = useNavigate();
  const [exam, setExam] = useState(null);
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch(`http://127.0.0.1:8000/get_exam/${examId}`).then(r => r.json()),
      fetch(`http://127.0.0.1:8000/get_quiz/${examId}`).then(r => r.json()),
    ])
      .then(([examData, questionsData]) => {
        setExam(examData);
        setQuestions(Array.isArray(questionsData) ? questionsData : []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [examId]);

  const startExam = () => navigate(`/exam/${examId}`, { state: { exam, questions } });
  const modeCount = (mode) => questions.filter(q => q.mode === mode).length;

  return (
    <div className="dashboard-container">
      <Sidebar />
      <div className="dashboard-main">
        <Navbar />
        <div style={{ padding: 28, background: "#f5f7fb", minHeight: "100vh", overflowY: "auto", paddingBottom: 48 }}>

          <button onClick={() => navigate("/exams")} style={{ background: "none", border: "none", color: "#3b82f6", cursor: "pointer", fontSize: 14, fontWeight: 600, marginBottom: 20, display: "flex", alignItems: "center", gap: 6 }}>
            ← Back to Exams
          </button>

          {loading ? (
            <div style={{ textAlign: "center", padding: "80px 0", color: "#6b7280" }}>
              <div style={{ fontSize: 40 }}>⏳</div>
              <p style={{ fontWeight: 600, marginTop: 12 }}>Loading exam...</p>
            </div>
          ) : exam ? (
            <>
              {/* Exam Header */}
              <div style={{ background: "#fff", borderRadius: 16, padding: 28, marginBottom: 24, boxShadow: "0 2px 12px #0001", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 16 }}>
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
                    <h1 style={{ margin: 0, fontSize: 28, fontWeight: 800, color: "#1e293b" }}>{exam.exam_name}</h1>
                    <span style={{ background: "#d1fae5", color: "#065f46", padding: "3px 12px", borderRadius: 20, fontSize: 12, fontWeight: 700 }}>Active</span>
                  </div>
                  <div style={{ display: "flex", gap: 20, flexWrap: "wrap" }}>
                    <span style={{ color: "#6b7280", fontSize: 14 }}>📄 <strong>{exam.subject_name}</strong></span>
                    <span style={{ color: "#6b7280", fontSize: 14 }}>⏱ <strong>{exam.duration} min</strong></span>
                    <span style={{ color: "#6b7280", fontSize: 14 }}>🏆 <strong>{exam.total_marks} marks</strong></span>
                    <span style={{ color: "#6b7280", fontSize: 14 }}>📅 <strong>{exam.start_date}</strong></span>
                    <span style={{ color: "#6b7280", fontSize: 14 }}>📝 <strong>{questions.length} questions</strong></span>
                  </div>
                </div>
                <button onClick={startExam} disabled={questions.length === 0}
                  style={{ background: questions.length === 0 ? "#cbd5e1" : "linear-gradient(135deg,#3b82f6,#6366f1)", color: "#fff", border: "none", borderRadius: 14, padding: "16px 36px", fontSize: 17, fontWeight: 800, cursor: questions.length === 0 ? "not-allowed" : "pointer", boxShadow: questions.length > 0 ? "0 4px 20px #3b82f640" : "none", display: "flex", alignItems: "center", gap: 10 }}>
                  🚀 Start Exam
                </button>
              </div>

              {/* Stats */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16, marginBottom: 24 }}>
                {[
                  { label: "Total Questions", value: questions.length, icon: "📝", bg: "#eff6ff", color: "#1d4ed8" },
                  { label: "Easy",   value: modeCount("Easy"),   icon: "🟢", bg: "#f0fdf4", color: "#166534" },
                  { label: "Medium", value: modeCount("Medium"), icon: "🟡", bg: "#fefce8", color: "#854d0e" },
                  { label: "Hard",   value: modeCount("Hard"),   icon: "🔴", bg: "#fff1f2", color: "#9f1239" },
                ].map(s => (
                  <div key={s.label} style={{ background: s.bg, borderRadius: 14, padding: "20px 22px" }}>
                    <p style={{ margin: 0, fontSize: 13, color: "#6b7280" }}>{s.icon} {s.label}</p>
                    <p style={{ margin: "6px 0 0", fontSize: 32, fontWeight: 800, color: s.color }}>{s.value}</p>
                  </div>
                ))}
              </div>

              {/* Instructions - NO question preview */}
              <div style={{ background: "#fff", borderRadius: 16, padding: 28, boxShadow: "0 2px 12px #0001", display: "flex", flexDirection: "column" }}>
                <h2 style={{ margin: "0 0 16px", fontSize: 18, fontWeight: 700 }}>📋 Exam Instructions</h2>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                  {[
                    { icon: "⏱", title: "Time Limit", desc: `You have ${exam.duration} minutes. Timer starts when you click Start Exam.` },
                    { icon: "📷", title: "Camera Required", desc: "Your webcam stays active throughout for proctoring. Ensure good lighting." },
                    { icon: "👁", title: "Face Monitoring", desc: "Keep your face visible and look at the screen at all times." },
                    { icon: "📝", title: `${questions.length} Questions`, desc: "Navigate between questions using the question palette." },
                    { icon: "✅", title: "Scoring", desc: "Each correct answer earns 1 mark. No negative marking." },
                    { icon: "🚫", title: "No Cheating", desc: "Suspicious movements are logged and reported automatically." },
                  ].map(ins => (
                    <div key={ins.title} style={{ display: "flex", gap: 12, padding: "14px 16px", background: "#f8fafc", borderRadius: 10 }}>
                      <span style={{ fontSize: 20, flexShrink: 0 }}>{ins.icon}</span>
                      <div>
                        <p style={{ margin: 0, fontWeight: 700, fontSize: 14, color: "#1e293b" }}>{ins.title}</p>
                        <p style={{ margin: "3px 0 0", fontSize: 13, color: "#6b7280", lineHeight: 1.4 }}>{ins.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>

                {questions.length === 0 && (
                  <div style={{ marginTop: 16, padding: "14px 18px", background: "#fef3c7", borderRadius: 10, color: "#92400e", fontSize: 14, fontWeight: 600 }}>
                    ⚠ No questions found. Create the exam again with Ollama running.
                  </div>
                )}

                <button onClick={startExam} disabled={questions.length === 0}
                  style={{ marginTop: 20, width: "100%", padding: "15px 0", fontSize: 16, fontWeight: 800, background: questions.length === 0 ? "#cbd5e1" : "linear-gradient(135deg,#3b82f6,#6366f1)", color: "#fff", border: "none", borderRadius: 12, cursor: questions.length === 0 ? "not-allowed" : "pointer", boxShadow: questions.length > 0 ? "0 4px 16px #3b82f640" : "none", display: "block" }}>
                  🚀 Start Exam Now
                </button>
              </div>
            </>
          ) : (
            <div style={{ textAlign: "center", padding: "60px 0", color: "#9ca3af" }}>
              <div style={{ fontSize: 48 }}>❌</div><p>Exam not found.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default ExamView;
