import "./Navbar.css";
import { FaBell, FaSignOutAlt } from "react-icons/fa";
import { useNavigate } from "react-router-dom";

function Navbar() {
  const navigate = useNavigate();
  const userRaw = localStorage.getItem("exam_user");
  const user = userRaw ? JSON.parse(userRaw) : null;

  const handleLogout = () => {
    localStorage.removeItem("exam_user");
    navigate("/login");
  };

  return (
    <div className="navbar">
      <div className="nav-left">
        <h3>Welcome{user ? `, ${user.name}` : ""}</h3>
        <p className="nav-subtitle">Manage your examination system</p>
      </div>
      <div className="nav-right">
        <div className="notification">
          <FaBell className="bell" />
          <span className="dot"></span>
        </div>
        {user && (
          <div className="nav-user">
            <div className="nav-avatar">{user.name?.[0]?.toUpperCase() || "U"}</div>
            <div className="nav-user-info">
              <span className="nav-user-name">{user.name}</span>
              <span className="nav-user-role">{user.role}</span>
            </div>
          </div>
        )}
        <button className="nav-logout" onClick={handleLogout} title="Logout">
          <FaSignOutAlt /> Logout
        </button>
      </div>
    </div>
  );
}

export default Navbar;
