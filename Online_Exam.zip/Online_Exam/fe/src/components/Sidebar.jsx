import { Link, useNavigate } from "react-router-dom";
import "./Sidebar.css";

function Sidebar() {
  const navigate = useNavigate();
  const userRaw = localStorage.getItem("exam_user");
  const user = userRaw ? JSON.parse(userRaw) : null;
  const role = (user?.role || "").toLowerCase();

  const handleLogout = () => {
    localStorage.removeItem("exam_user");
    navigate("/login");
  };

  return (
    <div className="sidebar">
      <h2 className="logo">📚 Smart Exam System</h2>
      <ul>
        {(role === "admin") && (
          <>
            <li><Link to="/">🏠 Dashboard</Link></li>
            <li><Link to="/users">👥 Users</Link></li>
            <li><Link to="/exams">📋 Exams</Link></li>
            <li><Link to="/questions">❓ Questions</Link></li>
            <li><Link to="/results">📊 Results</Link></li>
            <li><Link to="/security">🔒 Security</Link></li>
          </>
        )}
        {(role === "teacher") && (
          <>
            <li><Link to="/teacher">🏠 Dashboard</Link></li>
            <li><Link to="/exams">📋 Manage Exams</Link></li>
            <li><Link to="/questions">❓ Question Bank</Link></li>
            <li><Link to="/results">📊 Results</Link></li>
            <li><Link to="/evaluation">✅ Evaluation</Link></li>
          </>
        )}
      </ul>
      <div className="sidebar-bottom">
        {user && (
          <div className="sidebar-user-info">
            <div className="sidebar-avatar-sm">{user.name?.[0]?.toUpperCase() || "U"}</div>
            <div>
              <div className="sidebar-uname">{user.name}</div>
              <div className="sidebar-urole">{role}</div>
            </div>
          </div>
        )}
        <button className="sidebar-logout" onClick={handleLogout}>🚪 Logout</button>
      </div>
    </div>
  );
}

export default Sidebar;
