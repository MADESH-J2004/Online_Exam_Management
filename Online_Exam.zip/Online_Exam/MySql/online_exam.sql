-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2026 at 07:12 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_exam`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_table`
--

CREATE TABLE `activity_table` (
  `id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `exam_name` varchar(100) DEFAULT NULL,
  `activity` varchar(255) DEFAULT NULL,
  `severity` varchar(50) DEFAULT NULL,
  `time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `answer_table`
--

CREATE TABLE `answer_table` (
  `answer_id` int(15) NOT NULL,
  `user_id` int(15) DEFAULT NULL,
  `question_id` int(15) DEFAULT NULL,
  `selected_answer` varchar(50) DEFAULT NULL,
  `mark` int(1) DEFAULT NULL,
  `exam_id` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `answer_table`
--

INSERT INTO `answer_table` (`answer_id`, `user_id`, `question_id`, `selected_answer`, `mark`, `exam_id`) VALUES
(1, 1, 1, 'H2O', 1, 1),
(2, 1, 2, '2x', 1, 1),
(3, 1, 3, 'F=ma', 1, 1),
(4, 1, 4, 'Mitochondria', 1, 1),
(5, 1, 5, '3.14159', 1, 1),
(6, 2, 1, 'H2O', 1, 2),
(7, 2, 2, '2x', 1, 2),
(8, 2, 3, 'F=ma', 1, 2),
(9, 2, 4, 'Mitochondria', 1, 2),
(10, 2, 5, '3.14159', 1, 2),
(11, 3, 1, 'H2O', 1, 3),
(12, 3, 2, 'x', 0, 3),
(13, 3, 3, 'V=IR', 0, 3),
(14, 3, 4, 'Mitochondria', 1, 3),
(15, 3, 5, '3.14159', 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `exam_table`
--

CREATE TABLE `exam_table` (
  `exam_id` int(15) NOT NULL,
  `exam_name` varchar(100) DEFAULT NULL,
  `duration` int(10) DEFAULT NULL,
  `total_marks` int(10) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date NOT NULL,
  `subject_name` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exam_table`
--

INSERT INTO `exam_table` (`exam_id`, `exam_name`, `duration`, `total_marks`, `start_date`, `end_date`, `subject_name`) VALUES
(1, 'Mathematics Final Exam', 60, 100, '2026-03-07', '2026-03-08', 'Mathematics'),
(2, 'Physics Mid-term', 90, 100, '2026-03-09', '2026-03-10', 'Physics'),
(3, 'Chemistry Quiz', 120, 100, '2026-03-11', '2026-03-12', 'Chemistry'),
(4, 'Biology Quiz', 90, 100, '2026-03-16', '2026-03-17', 'Biology');

-- --------------------------------------------------------

--
-- Table structure for table `question_table`
--

CREATE TABLE `question_table` (
  `question_id` int(15) NOT NULL,
  `exam_id` int(15) DEFAULT NULL,
  `question_title` varchar(100) NOT NULL,
  `option_a` varchar(50) DEFAULT NULL,
  `option_b` varchar(50) DEFAULT NULL,
  `option_c` varchar(50) DEFAULT NULL,
  `option_d` varchar(50) DEFAULT NULL,
  `correct_answer` varchar(50) DEFAULT NULL,
  `mode` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `question_table`
--

INSERT INTO `question_table` (`question_id`, `exam_id`, `question_title`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_answer`, `mode`) VALUES
(1, 3, 'What is the chemical formula for water?', 'H2O', 'CO2', 'O2', 'N2', 'H2O', 'Easy'),
(2, 1, 'What is the derivative of x^2?', '2x', 'x', 'x^2', '2', '2x', 'Medium'),
(3, 2, 'What is Newton`s Second Law of Motion?', 'F=ma', 'E=mc^2', 'V=IR', 'P=W/t', 'F=ma', 'Hard'),
(4, 4, 'What is the powerhouse of the cell?', 'Nucleus', 'Ribosome', 'Mitochondria', 'Chloroplast', 'Mitochondria', 'Easy'),
(5, 1, 'What is the value of π (pi)?', '3.14159', '2.71828', '1.61803', '4.66920', '3.14159', 'Hard');

-- --------------------------------------------------------

--
-- Table structure for table `result_table`
--

CREATE TABLE `result_table` (
  `result_id` int(15) NOT NULL,
  `user_id` int(15) NOT NULL,
  `total_quiz` int(3) NOT NULL,
  `correct_answers` int(3) NOT NULL,
  `wrong_answers` int(3) NOT NULL,
  `percentage` int(3) NOT NULL,
  `result_status` varchar(10) NOT NULL,
  `result_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `exam_id` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `result_table`
--

INSERT INTO `result_table` (`result_id`, `user_id`, `total_quiz`, `correct_answers`, `wrong_answers`, `percentage`, `result_status`, `result_date`, `exam_id`) VALUES
(1, 1, 5, 5, 0, 100, 'PASS', '2026-03-08 12:48:56', 1),
(2, 2, 5, 5, 0, 100, 'PASS', '2026-03-08 12:51:04', 2),
(3, 3, 5, 3, 2, 60, 'PASS', '2026-03-08 12:51:21', 3);

-- --------------------------------------------------------

--
-- Table structure for table `users_table`
--

CREATE TABLE `users_table` (
  `user_id` int(15) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `role` varchar(10) NOT NULL,
  `joinig_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(15) NOT NULL DEFAULT 'Active',
  `phone_no` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users_table`
--

INSERT INTO `users_table` (`user_id`, `name`, `email`, `password`, `role`, `joinig_at`, `status`, `phone_no`) VALUES
(1, 'Naresh', 'nareshbca@gmail.com', '@naresh', 'Student', '2026-03-07 13:37:41', 'Active', 9994898494),
(2, 'Raja', 'rajabca@gmail.com', '@raja', 'Student', '2026-03-07 13:49:57', 'Active', 8778417448),
(3, 'Ragu', 'ragubca@gmail.com', '@ragu', 'Student', '2026-03-07 13:50:56', 'Active', 8072933694);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_table`
--
ALTER TABLE `activity_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `answer_table`
--
ALTER TABLE `answer_table`
  ADD PRIMARY KEY (`answer_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `question_id` (`question_id`),
  ADD KEY `exam_id` (`exam_id`);

--
-- Indexes for table `exam_table`
--
ALTER TABLE `exam_table`
  ADD PRIMARY KEY (`exam_id`);

--
-- Indexes for table `question_table`
--
ALTER TABLE `question_table`
  ADD PRIMARY KEY (`question_id`),
  ADD KEY `exam_id` (`exam_id`);

--
-- Indexes for table `result_table`
--
ALTER TABLE `result_table`
  ADD PRIMARY KEY (`result_id`),
  ADD KEY `exam_id` (`exam_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users_table`
--
ALTER TABLE `users_table`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_table`
--
ALTER TABLE `activity_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `answer_table`
--
ALTER TABLE `answer_table`
  MODIFY `answer_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `exam_table`
--
ALTER TABLE `exam_table`
  MODIFY `exam_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `question_table`
--
ALTER TABLE `question_table`
  MODIFY `question_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `result_table`
--
ALTER TABLE `result_table`
  MODIFY `result_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users_table`
--
ALTER TABLE `users_table`
  MODIFY `user_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `answer_table`
--
ALTER TABLE `answer_table`
  ADD CONSTRAINT `answer_table_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users_table` (`user_id`),
  ADD CONSTRAINT `answer_table_ibfk_2` FOREIGN KEY (`question_id`) REFERENCES `question_table` (`question_id`),
  ADD CONSTRAINT `answer_table_ibfk_3` FOREIGN KEY (`exam_id`) REFERENCES `exam_table` (`exam_id`);

--
-- Constraints for table `question_table`
--
ALTER TABLE `question_table`
  ADD CONSTRAINT `question_table_ibfk_1` FOREIGN KEY (`exam_id`) REFERENCES `exam_table` (`exam_id`);

--
-- Constraints for table `result_table`
--
ALTER TABLE `result_table`
  ADD CONSTRAINT `result_table_ibfk_1` FOREIGN KEY (`exam_id`) REFERENCES `exam_table` (`exam_id`),
  ADD CONSTRAINT `result_table_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users_table` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
